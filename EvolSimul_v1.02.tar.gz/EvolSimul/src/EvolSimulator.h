#ifndef EVOL_SIMULATOR_H
#define EVOL_SIMULATOR_H

#include "SeqAnnotator.h"
#include "ExprPredictor.h"
#include "EvolModels.h"

#define INSERTION 1
#define DELETION -1
#define SUBSTITUTION 0

#define MAXPRINT 0

/* Define the Stopping Criteria
   All stopping criteria (except for distance work the same way:
   We start checking after a minimun number of generations (nGenerations)
   After that time, we check if a criteria is met for tc generations in a row
   In any case, we stop after at most maxGenerations
*/
enum StoppingCriteriaOptions {DEFAULT = 0,  // based on number of fit solutions
		                      GENERATIONS = 1,  // Fixed number of generations
							  DISTANCE = 2,   // Stop based on distance from original
							  AVG = 3,  // Based on average fitness of population
							  MIN = 4,  // All individuals are fit
							  MAX = 5,  // At least one individual is fit
							 };


// distance between two sequences (number of substitutions)
int compDistance( const Sequence& seq1, const Sequence& seq2 );

/* SequenceCompact class: the compact representation of a sequence, storing only the differences with a reference sequence */
class SequenceCompact {
	friend class EvolSimulator;
	
	
  public:
	
	// constructors
	SequenceCompact( const Sequence& _refSeq ) : refSeq( _refSeq ) {
			length = _refSeq.size(); max_length = length; currentDistance = 0.0;}
	SequenceCompact(const SequenceCompact& other) : refSeq(other.refSeq) { 
			copy( other ); }

	// assignment
	void copy(const SequenceCompact &other);
	SequenceCompact& operator=( const SequenceCompact& other ) { 
			copy( other ); return *this; }

	// reconstruct the original sequence
	void reconstructSeq( Sequence& origSeq ) const;
	void reconstructWithoutIndels (Sequence &origSeq) const;
	void reconstructGappedAlignment (Sequence &origSeq) const;

	// Add a change
	void addSubstitution (int position, int newAllele);
	void addIndel (int position, int length, Sequence &seq, int type);

	int size();

	// Serializes this object to a string
	string SerializeToString() const ;
	
	double getDistance() {return currentDistance;}; 

  private:
	
	void calculateDistance ();
	void calculateDistanceDeprecated ();

	const Sequence& refSeq;			// reference sequence
	vector< int > indelPositions;
	vector< int > indelLenghts;
	vector< Sequence > indelSequences;
	vector< int > indelTypes;
	double currentDistance;  // distance between this and initial seq
	int length;
	int max_length;  // The lenght or refSeq plus all insertions
};



/* Environment class: the trans- conditions that affect the phenotype */
class Environment {
	friend class PhenotypeFunc;
	public:
		// constructors
		Environment( const Matrix& _factorExprProfiles ) : factorExprProfiles( _factorExprProfiles ) {}
		void copy( const Environment& other ) {
			factorExprProfiles = other.factorExprProfiles;
		}
		Environment( const Environment& other ) {
			copy( other ); 
		}

		// assignment
		Environment& operator=( const Environment& other ) { copy( other ); return *this; }

		// access methods
		const Matrix& getFactorExprProfiles() const {
			return factorExprProfiles;
		}
	private:	
		Matrix factorExprProfiles;	// the expression profiles of transcription factors
};



/* Phenotype class: the phenotype of the sequence */
class Phenotype {

	friend class PhenotypeFunc;
	friend class FitnessFunc;

	public: 

		// constructors
		Phenotype() : exprProfile() {}
		Phenotype( const vector< double > _exprProfile ) : exprProfile( _exprProfile ) {}
		void copy( const Phenotype& other ) { exprProfile = other.exprProfile; }
		Phenotype( const Environment& other ) { copy( other ); }

		// assignment
		Phenotype& operator=( const Phenotype& other ) { copy( other ); return *this; }

		// access methods
		const vector< double >& getExprProfile() const { return exprProfile; }

		// print
		friend ostream& operator<<( ostream& os, const Phenotype& pheno );

		vector< double > exprProfile;   // 1D expression profile
	private:	
};



/* PhenotypeFunc class: the genotype-phenotyp map */
class PhenotypeFunc {
	public: 
		// constructors
		PhenotypeFunc( ExprFunc* _exprFunc, const vector< double >& _energyThrs, const Environment& _env ) 
			: exprFunc( _exprFunc ), energyThrs( _energyThrs ), env( _env ){ ann = new SeqAnnotator( exprFunc->getMotifs(), energyThrs );}

		// compute the phenotype from the sequence and environment
		void computePhenotype( const Sequence& seq, Phenotype& pheno ) const;

		// test if a sequence contains another sequence (as a substring)
		//     static bool contains( const Sequence& seq, const Sequence& elem );   

	//private:
		ExprFunc* exprFunc;      // ExprFunc object to compute the phenotype of a sequence
		const vector< double >& energyThrs;	    // energy thresholds for all motifs  
		const Environment& env;        // environment
		SeqAnnotator *ann;	
};



/* FitnessFunc class: the fitness function that maps phenotype to fitness */
class FitnessFunc {
	public:
		// constructors
		FitnessFunc( const Phenotype& _target ) : target( _target ) {}

		// compute the fitness of a phenotype: (1- D/D_max)^p
		double computeFitness( const Phenotype& pheno ) const;

		//The deviation between two phenotypes: root mean squared error
		static double phenotypeDev( const Phenotype& pheno1, const Phenotype& pheno2 );

		// the maximum deviation
		static double D_max; 

		// the parameter of selection (p)
		static double selectionExp;

		Phenotype target;   // target phenotype
	private: 
};



/* EvolSimulator class: simulate the evolution of a population of sequences */
class EvolSimulator {
	friend class PopulationSummarizer;

	public: 
		// constructors
		EvolSimulator( const gsl_rng* _rng, double _mutationRate,
				ExprFunc* _exprFunc, const vector< double >& _energyThrs, 
				const Environment& _env, const Phenotype& _evolTarget,
				SubstModel *_bgModel);

		// access methods
		int getTime() const {
			return time;
		}
		const PhenotypeFunc* getPhenoFunc() const {
			return phenoFunc;
		}
		const FitnessFunc* getFitnessFunc() const {
			return fitnessFunc;
		}

		// initialize the population with a sequence 
		void initialize( int N, const Sequence& initSeq );
		void setIndelParameters(double substitution_probability, 
						     	double insertion_probability,
								double tandem_repeat_probability);

		// Prints the predicted expression for a sequence.
		void savePredictedExpression(int N, const Sequence& initSeq, string seqName);
		
		// evolve the population for a certain number of generations
		// second argument, if greater than 0, is a number greater than the first argument, 
		// prescribing the simulation to proceed until maxGenerations or until the majority achieves fitness of 
		// EvolSimulator::targetFitness, whichever happens first
		void evolve( int nGenerations, int maxGenerations = 0 );

		// print the population (for debugging purpose)
		void print(bool forcePrint = false) const;
		void print(bool printAll, string filename) const;
		void printAligned(bool printAll, string filename) const;
		void printToCout(bool printAll) const;
	
		// Serializes the population so it can be loaded again to re-start 
		void SerializePopulation (const string& file_name) const;

		// Unserializes the population
		void UnserializePopulation();

		static int printTime;
		static double printProb;
		static double distanceThreshold;
		static vector<double> printTimesList;
		int nextPrintTimeIndex;
	
		static int stoppingCriteria; 

		// if simulating beyond minimum number of generations, stop
		// when a percentage of the population reaches this value.
		static double targetFitness; 

		static double adaptationRatio;
		//Some statistics about the poulations:
		int countFit;  // The number of solutions considered fit.
		int maxFitId;  // The of the most fit solution
		double maxFit; // The fitness of the most fit solution
		double avgFit;
		double minFit;

		static int tc;

		static double selectionScale;
		static double selectionCoeff;

		
	private: 
		const gsl_rng* rng; 	// random number generator

		double mutationRate;		// mutation rate
		double substitution_probability;
		double insertion_probability;
		double tandem_repeat_probability;

		ExprFunc* exprFunc;  // the ExprFunc object, containing the relevant parameters
		vector< double > energyThrs;     // the energy thresholds for all motifs
		Environment env;	// the current environment
		Phenotype evolTarget;	// the evolutionary target
		//     double selectionCoeff;  // the selection coefficient

		int time;	// the current generation time
		int last_print_time;	// the generation of the last time we printed something
		int n_printed;
		Sequence refSeq;	// the reference sequence
		vector< SequenceCompact > population;	// the current population of sequences
		vector< double > fitnesses;		// the fitness of each sequence

		PhenotypeFunc* phenoFunc;		// genotype-to-phenotype function
		FitnessFunc* fitnessFunc;		// phenotype-to-fitness function

		SubstModel *bgModel;  // The backgroud model of substititution.

		// compute the fitness of a sequence
		//     double computePhenotype( const SequenceCompact& seq ) const;
		double computeFitness( const SequenceCompact& seq ) const;

		// mutation of one sequence (random substitution)
		void doMutations(int nMutations);
		void mutate( SequenceCompact& currSeq, int pos ) const;
		void indel( SequenceCompact& currSeq, int pos, int len, int type) const;
		int insertionLength();
		int deletionLength();

		bool checkDistanceStoppinCriteria();
		bool checkDistance(double distanceThreshold);
		void checkDistanceForPrinting();

		// sample next generation of 2N individuals
		void sampleNextGeneration( vector< int >& nextGen ) const; 		
};



/* PopulationSummarizer class: summarize the statistics of a population, e.g. consensus sequence, best phenotype, etc. */
class PopulationSummarizer {
	public: 
		// constructors
		PopulationSummarizer( const EvolSimulator& _simulator ) : simulator( _simulator ) {}

		// the sequence with the highest fitness: return the fitness value
		double getBestSeq( Sequence& bestSeq, Phenotype& bestPheno );

		// sample a set of sequences from the population
		void sampleSeqs( const gsl_rng* rng, int n, vector< Sequence >& seqs ) const;

		// sample a single sequence from the population
		void sampleSeq( const gsl_rng* rng, Sequence& seq ) const;
	private: 
		const EvolSimulator& simulator;		// reference to the evolutionary simulator	
};

#endif

