#include "Motif.h"

/******************************************************************************
** TfbsMotif
******************************************************************************/

// TfbsMotif constructor
TfbsMotif::TfbsMotif( const Matrix& _pwm, const vector< double >& _background ) : Motif( _pwm, _background ), background( _background ), energyMat( pwm.getRows(), 4 )
{
	assert( background.size() == 4 );	
	
	init();
}

// TfbsMotif constructor: construct PWM from the count matrix
// countMatrix in Transfac format
TfbsMotif::TfbsMotif( const Matrix& countMatrix, double pseudoCount, const vector< double >& _background ) : Motif( countMatrix, pseudoCount, _background ), background( _background ), energyMat( pwm.getRows(), 4 )
{
	assert( background.size() == 4 );
	
	init();
}

TfbsMotif::TfbsMotif(const Motif& motif, const vector<double>& _background) : 
		Motif(motif), background(_background), energyMat(motif.getPwm().getRows(), 4) {
	assert( background.size() == 4 );	
	
	init();
}

TfbsMotif TfbsMotif::compRevCompl() const
{
	// compute PWM of the rev. compl. motif
	int l = length();
	Matrix rc_pwm( l, NBASES );
	for ( int i = 0; i < l; i++ ) {
		for ( int j = 0; j < NBASES; j++ ) {
			rc_pwm( i, j ) = pwm( l - 1 - i, complement( j ) );
		}	
	}
	
	// construct the rev. compl. motif
	return TfbsMotif( rc_pwm, background );
}

// TfbsMotif: compute the energy (log-likelihood) of a site 
double TfbsMotif::energy( const SeqElement& elem ) const
{
	int l = pwm.getRows();
	if( elem.size() != l ) return GSL_NEGINF;
	
	double result = 0;
	for ( int i = 0; i < l; i++ ) {
		// energy at position i
		int nt = elem[ i ];
		result += energyMat( i, nt ); 	
	}
	
	return result;
}

double TfbsMotif::comp_ll( const SeqElement& elem ) const
{
	int l = pwm.getRows();
	assert( elem.size() == l );
	
	double result = 0;
	for ( int i = 0; i < l; i++ ) {
		int nt = elem[ i ];
		result += log( pwm( i, nt ) );
	}
	
	return result;
}

// TfbsMotif: sample a site whose energy is larger than a threshold
void TfbsMotif::sampleGoodSite( const gsl_rng* rng, SeqElement& elem, double thr ) const
{
	assert( rng != NULL );
	double curr_energy = GSL_NEGINF;
	
	while ( curr_energy < thr ) {
		Sequence seq;
		sample( rng, seq );
		elem = SeqElement(seq, 0, seq.size());
		curr_energy = energy( elem );
	}
}

int TfbsMotif::load( const string& file, const vector< double >& background , string& name )
{
	vector< TfbsMotif > motifs;
	vector< string > names;
	int rval = readMotifs( file, background, motifs, names );
	if ( rval == RET_ERROR ) return RET_ERROR;
	
	copy( motifs[ 0 ] );
	name = names[ 0 ];
	return rval;				
}

int TfbsMotif::load( const string& file, const vector< double >& background )
{
	string name;
	int rval = load( file, background, name );
	
	return rval;	
}

// output the TfbsMotif
ostream& operator<<( ostream& os, const TfbsMotif& motif )
{
	os << motif.pwm;
	
	return os;
}

// TfbsMotif: initialization
void TfbsMotif::init()
{
	int l = pwm.getRows();
	
	// compute the energy matrix
	for ( int i = 0; i < l; i++ ) {
		for ( int j = 0; j < 4; j++ ) {
			// nt. distribution at position i
			vector< double > distr = pwm.getRow( i );
			
			// energy of nt. j at position i
			energyMat( i, j ) = log( distr[ j ] / background[ j ] );
		}
	}
	
	energyComputed = true;
}


/*****************************************************************************
** Helper methods to read motifs
******************************************************************************/

// read the motifs (PWMs) in a FASTA-like format: pseudocounts within the file
int readMotifs( const string& file, vector< Motif >& motifs, vector< string >& names )
{
	// 	open the file
	ifstream fin( file.c_str() );
	if ( !fin ) { cerr << "Cannot open" << file << endl; exit( 1 ); }

	string line;
	
	// read the motifs
	do {
		getline( fin, line );
		
		if ( line[ 0 ] != '>' ) continue;
		
		// read the names, length and pseudocount
		int MAX_SIZE = 100;
		char lineStr[ MAX_SIZE ];
		strcpy( lineStr, ( line.substr( 1 ) ).c_str() );
		char *name, *lengthStr, *pseudoCountStr;
		name = strtok( lineStr, " \t" );
		lengthStr = strtok( NULL, " \t" );
		pseudoCountStr = strtok( NULL, " \t" );
		int length;
		double pseudoCount;
		if ( lengthStr ) length = atoi( lengthStr );
		else { return RET_ERROR; }
		if ( pseudoCountStr ) pseudoCount = atof( pseudoCountStr );
		else pseudoCount = 0;
		
		// read the count matrix
		Matrix countMat( length, NBASES );
		for ( int i = 0; i < length; ++i ) {
			for ( int j = 0; j < NBASES; ++j ) {
				fin >> countMat( i, j );
			}	
		}
		
		// create the motif
		names.push_back( string( name ) );
		motifs.push_back( Motif( countMat, pseudoCount ) );
		
	} while ( !fin.eof() );
					
	return 0;
}

int readMotifs( const string& file, vector< Motif >& motifs )
{
	vector< string > names;
	return readMotifs( file, motifs, names );	
}

int readMotifs( const string& file, const vector< double >& background, vector< TfbsMotif >& motifs, vector< string >& names )
{
	vector< Motif > preMotifs;
	int rval = readMotifs( file, preMotifs, names );
	if ( rval == RET_ERROR ) return rval;
	motifs.clear();
	for ( int i = 0; i < preMotifs.size(); i++ ) {
		motifs.push_back( TfbsMotif( preMotifs[ i ].getPwm(), background ) );
	}
	
	return rval;	
}

int readMotifs( const string& file, const vector< double >& background, vector< TfbsMotif >& motifs )
{
	vector< string > names;
	return readMotifs( file, background, motifs, names );	
}

/*****************************************************************************
** SeqElement
******************************************************************************/

// SeqElement constructor: from S[ start, start + length - 1 ] where S is a Sequence
SeqElement::SeqElement( const Sequence& seq, int start, int length )
{
	assert( start >= 0 && length >= 0 && ( start + length ) <= seq.size() );
	
	for ( int i = 0; i < length; i++ ) {
		nts.push_back( seq[ start + i ] );	
	}
}

// SeqElement: insert a nt. at the end of sequence
int SeqElement::push_back( int nt )
{
	assert( nt >= 0 && nt < ALPHABET_SIZE );
	
	nts.push_back( nt );		
}

// SeqElement: remove gaps, i.e. restore the sequence element
SeqElement SeqElement::restoreElem() const
{
	SeqElement result;
	for ( int i = 0; i < nts.size(); i++ ) {
		if ( nts[ i ] != GAP ) result.push_back( nts[ i ] );	
	}
	
	return result;
}

SeqElement SeqElement::compRevCompl() const
{
	SeqElement rcElem;
	for ( int i = nts.size() - 1; i >= 0; i-- ) {
		rcElem.push_back( complement( nts[ i ] ) );	
	}
	
	return rcElem;
}

double SeqElement::comp_ll( const vector< double >& pi ) const
{
	assert( pi.size() == 4 && isPmf( pi ) );
	
	double result = 0;
	for ( int i = 0; i < nts.size(); i++ ) {
		result += log( pi[ nts[ i ] ] );
	}	
	
	return result;
}

// output the SeqElemnt
ostream& operator<<( ostream& os, const SeqElement& elem )
{
	// output the nts
	for ( int i = 0; i < elem.size(); i++ ) {
		os << ALPHABET[ elem[ i ] ];	
	}
	
	return os;	
	//os << endl;	
}

