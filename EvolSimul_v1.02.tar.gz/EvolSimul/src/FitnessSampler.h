#ifndef FITNESS_SAMPLER
#define FITNESS_SAMPLER

#include "SeqAnnotator.h"
#include "EvolSimulator.h"

/* SequenceSampler class: sample a sequence with a given configuration (numbers of sites of each motif */
class SequenceSampler {
public:
	// constructor 
	SequenceSampler( const gsl_rng* _rng, const vector< Motif >& _motifs, 
					 const vector< double >& _bgFreqs, const vector< double >& _energyThrs,
					 int _useLR);

    // check if a configuration is legitimate (not too many sites)
    bool isConfigLeg( const vector< int >& config, int L ) const; 
    
	// the sampling method: the vector config stores the configuration, L is the length of sequence to be sampled
	int sample( const vector< int >& config, int L, Sequence& seq ) const; 

    // constants
    static double maxSiteRatio;     // maxmium ratio of the sequence occupied by binding sites
    static int ntrials;     // number of trials for sampling a site

	// These deal with sampling from a subset of the bidning sites, those above a threshold
	void ennumerateAllBindingSites(int motif, Sequence& seq, vector<Sequence> &sites);
	void prepareForSample();
	void sampleSite(int motif, Sequence &seq) const;

private: 
    // random number generator
    const gsl_rng* rng; 
    
	// TF binding motifs
    const vector< Motif >& motifs; 
    
	//The thresolds for each sequence
	const vector< double >& energyThrs;  // energy threshold for defining binding sites
	int useLR;

    // background nucleotide frequencies
    const vector< double >& bgFreqs; 

    /*methods used to manage the space of L positions */
    // test if the block[ pos, pos + l - 1 ] is available
    bool isBlockFree( const vector< int >& occ, int pos, int l ) const;  

    // mark a block to certain status
    int markBlock( vector< int >& occ, int pos, int l, int status ) const;

	// A list of all biding sites above the threshold
	vector< vector<Sequence> > allBidingSites;
};

/* FitnessInfo class: the mean and standard deviation of fitness of a certain configuration */
class FitnessInfo {
public:
    FitnessInfo( double _mean, double _sd, double _GEMinFit, int _n) : 
			mean( _mean ), sd( _sd ), GEMinFit(_GEMinFit), n(_n) {}
    
    double mean; 	// The mean fitness of all sequences;
    double sd;		// The std dev of the fitness of all sequences;
	double GEMinFit;// The probability that a sequence is (G)reater or (E)qual to the (MinFit)
	int n;			// The total number of sequences
	double meanFit; // The mean fitness among all fit sequences (above MinFit)
	double sdFit;   // The std dev of fitness among all fit sequences
	int nFit;		// The number of fit sequences
};

/* FitnessSummarizer class: given a set of sequences, compute the fitness function of any configuration */
class FitnessSummarizer {
public: 
    FitnessSummarizer( const vector< Motif >& _motifs, const vector< double >& _energyThrs, const vector< int >& _maxNumSites, const PhenotypeFunc* _phenoFunc, const FitnessFunc* _fitnessFunc, double _minFit, int _useLR );

    // calculate fitness of a sequence
    double compFitness( const Sequence& seq ) const; 
    
    // compute the fitness summary of a set of sequences: the mean fitness and its std_dev of any configuration
    int computeFitnessSummary( const vector< Sequence >& seqs, vector< FitnessInfo >& fitnessSummary ) const; 

    // class parameters
    static double nullFitnessVal;   // in case no sequence is sampled for a configuration, the null value for that configuration
private:
    double minFit; // The minimum fitness for a solution to be considered in the summary;
	int useLR;

    // motif information 
    const vector< Motif >& motifs; 
    const vector< double >& energyThrs;  // energy threshold for defining binding sites

    // define the space of genotypes/configurations: maximum number of sites per motif
    const vector< int >& maxNumSites;   
    
    // relevant functions for computing fitness of a sequence
    const PhenotypeFunc* phenoFunc;		// genotype-to-phenotype function
	const FitnessFunc* fitnessFunc;		// phenotype-to-fitness function

    // parse a sequence to get the number of sites of each motif
    int countSites( const Sequence& seq, vector< int >& nsites ) const;

    // test if a configuration is out of bound
    bool outOfBound( const vector< int >& config ) const;
};

#endif
