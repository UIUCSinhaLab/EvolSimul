#include <ctime>
#include <gsl/gsl_randist.h>
#include <sstream>
#include <fstream>

#include "BaseSiteSimulator.h"

// BaseSiteSimulator: constructor
BaseSiteSimulator::BaseSiteSimulator(const gsl_rng* _rng) : rng( _rng ) 
{
	assert( rng != NULL );	
}

// BaseSiteSimulator: frequencies of the site patterns in the simulation results
Matrix BaseSiteSimulator::patternFreq( double energyThr )
{	
	// initialize the count matrix
	Matrix counts( 2, 2 );
	counts.setZero();
	
	// count the patterns
	int N = simulatedPairs.size();
	for ( int i = 0; i < N; i++ ) {
		bool anc = simulatedPairs[ i ].first >= energyThr;
		bool desc = simulatedPairs[ i ].second >= energyThr;
		
		counts( anc, desc )++;	
	}	
	
	// frequencies
	Matrix freqs( 2, 2 );
	for ( int i = 0; i < 2; i++ ) 
		for ( int j = 0; j < 2; j++ )
			freqs( i, j ) = counts( i, j ) / (double)N;
			
	return freqs;
}

// BaseSiteSimulator: show simulation results
void BaseSiteSimulator::show() const 
{
	for ( int i = 0; i < simulatedPairs.size(); i++ ) {
		cout << simulatedPairs[ i ].first << "\t" << simulatedPairs[ i ].second << endl;	
	}	
}

