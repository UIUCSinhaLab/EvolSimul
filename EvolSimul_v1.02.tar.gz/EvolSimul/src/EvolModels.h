#ifndef EVOL_MODELS_H
#define EVOL_MODELS_H

#include "SeqAnnotator.h"
#include "BaseSequence.h"
#include "Tools.h"

using namespace std;

/*****************************************************
* Nucleotide Substitution Models
******************************************************/

// p22 in PAML manual
enum SubstModelType { JC, K80, F81, F84, HKY, T92, TN93, REV };

/* SubstModel class: implement the generic method of computing the transition probabilities via matrix exponential */
class SubstModel {
protected:
	Matrix rateMatrix;		// transition rate matrix
	vector< double > pi;	// equilibrium distribution 
public:
	// constructor
	SubstModel();
	SubstModel( const vector< double >& _pi );
	SubstModel( const Matrix& _rateMatrix, const vector< double >& _pi );
	
	// access methods
	const Matrix& getRateMatrix() const { return rateMatrix; }
	const vector< double >& getPi() const { return pi; }
	
	// the substitution rate
	double getRate() const;
	
	// compute the eigenvalues and eigenvectors of the rate matrix
	void diagonalize();
	
	// compute the transition probability matrix for a given time
	virtual Matrix compProbMatrix( double t );
	
	// compute the transition probability matrix for a range of time
	//virtual void compProbMatrices( vector< Matrix >& probMatrices, double t_min, double t_max, int nIntervals ) const;
	
	// propose a random change given the current nt.
	int randomMove( const gsl_rng* rng, int currNt );
	
	// I/O
	friend ostream& operator<<( ostream& os, const SubstModel& model );
protected:
	// diagonalization of the rate matrix: Q = U * Gamma * invU, where Gamma is diagonal
	vector< double > eigenvalues;
	Matrix U, invU;
};

/* JCModel class: Table 1.1 in "Computational Molecular Evolution", Yang */
class JCModel : public SubstModel {
	double rate;		// total substitution rate
public:
	// constructor
	JCModel( double _rate );
		
	// access methods
	double getRate() const { return rate; }
	void setRate( double _rate ) { assert( _rate > 0 ); rate = _rate; }
	
	// compute the transition probability matrix for a given time
	Matrix compProbMatrix( double t );
	
	// compute the transition probability matrix for a range of time
	//void compProbMatrices( vector< Matrix >& probMatrices, double t_min, double t_max, int nIntervals ) const;	
private:
	// initialization method
	void init();
};

/* F81Model class: from the original paper, Felsenstein, JME'81 */
class F81Model: public SubstModel {
	double rate;		// total substitution rate
public:
	// constructor
	F81Model( double _rate, const vector< double >& _pi );

	// access methods
	double getRate() const { return rate; }
	void setRate( double _rate ) { assert( _rate > 0 ); rate = _rate; }
	
	// compute the transition probability matrix for a given time
	Matrix compProbMatrix( double t );
	
	// compute the transition probability matrix for a range of time
	//void compProbMatrices( vector< Matrix >& probMatrices, double t_min, double t_max, int nIntervals ) const;
private:
	// initialization method
	void init();
};

/* HKYModel class: Table 1.1 in "Computational Molecular Evolution", Yang */
class HKYModel : public SubstModel {
	double alpha;			// transition rate
	double beta;			// transversion rate
public:
	// constructor
	HKYModel( double _alpha, double _beta, const vector< double >& _pi );
	// constructor: alternative parameterization
	// rate = average rate/site, bias = transition/transversion bias
	HKYModel( const vector< double >& _pi, double rate, double bias );

	// access methods
	double getAlpha() const { return alpha; }
	double getBeta() const { return beta; }
	void setRates( double _alpha, double _beta ) { assert( _alpha > 0 && _beta > 0 ); alpha = _alpha; beta = _beta; }
	
	// compute the transition probability matrix for a given time
	Matrix compProbMatrix( double t );
	
	// compute the transition probability matrix for a range of time
	//void compProbMatrices( vector< Matrix >& probMatrices, double t_min, double t_max, int nIntervals ) const;
private:
	// initialization method
	void init();
};

/* Halpern-Bruno model */
class HBModel : public SubstModel {
	const Matrix neutRateMatrix;	// transition rate matrix for neut sequences
public:
	// constructor
	HBModel( const vector< double >& _pi, const Matrix& _neutRateMatrix );
};

/*****************************************************
* Precomputing Data for a Given Model
******************************************************/

/* time related parameters */
class TimeParam {
public:	
	double t1, t2;	// branch lengths
	double delta_t;		// size of an interval
	
	int n1, n2, n;		// number of intervals of t1, t2 and t (total time), or branch length in delta_t unit
	
	// constructor
	TimeParam( double _t1, double _t2, double _delta_t );		
};

/* probabilities under an evolution model for different time (not equal to 0)*/
class EvolData {
public:		
	TimeParam tp;
	
	// evolutionary parameters
	vector< double > pi;	// stationary distribution of nts
	double rate;		// substitution rate
	double bias;		// transition/transversion bias
	double lambda;		// insertion rate
	double mu;			// deletion rate
	double r;			// indel length parameter
		
	// weight of a nt. (probability of sampling a nt.)
	double weight;
	
	// rate matrix of the substitution model
	Matrix rateMatrix;
	
	// precomputed data: equlibrium distribution
	vector< double > log_pi;
	
	// precomputed data: substitution probabilities
	vector< Matrix > transProbs;	// P(a-->b|t) for any a, b and t
	vector< Matrix > log_transProbs;	// log. of transProbs		
	vector< Matrix > probs;		// P(a,b|t) for any a, b and t
	vector< Matrix > log_probs;	// log. of probs
	
	// precomputed data: indel probabilities
	double log_r;		// log( r )
	double log_r_compl;		// log( 1 - r )
	vector< double > log_ins_probs;		// log( lambda * t ) for any t, 0 <= t <= t1 + t2
	vector< double > log_del_probs;		// log( mu * t ) for any t, 0 <= t <= t1 + t2
	vector< double > no_indel_probs;	// 1 - lambda * t - mu * t for any t
	vector< double > log_no_indel_probs;	// log( 1 - lambda * t - mu * t ) for any t, 0 <= t <= t1 + t2
	Matrix log_indel_probs;		// log( lambda * tuo1 + mu * tuo2 ), 0 <= tuo1, tuo2 <= t1 + t2
	Matrix log_indel_probs_compl;	// log( 1 - lambda * tuo1 - mu * tuo2 ), 0 <= tuo1, tuo2 <= t1 + t2
			
	// precomputed data: power of weight
	double log_weight;
	vector< double > weightPowers;
	
	static int maxLength;
	 
	// constructor
	EvolData( const TimeParam& _tp, const vector< double >& _pi, double _rate, double _bias, double _lambda, double _mu, double _r, double _weight = 1.0 );	
			
	// destructor
	~EvolData() {}
	
	// reset the data 
	void reset( double _weight );
	void reset( double _rate, double _lambda, double _mu, double _r );
	void reset( double _weight, double _rate, double _lambda, double _mu, double _r );
	
	// output
	friend ostream& operator<<( ostream& os, const EvolData& ed );
private:
	void compSubstProbs();
	void compIndelProbs();
	void compWeightProbs();
};


/*****************************************************
* Help Functions
******************************************************/

// test if a -> b is transition or transversion where a, b are nts.
/*bool isTransition( int a, int b )
{
	assert( isNt( a ) && isNt( b ) && a != b );
	
	if ( a == 0 && b == 2 ) return true;
	if ( a == 2 && b == 0 ) return true;
	if ( a == 1 && b == 3 ) return true;
	if ( a == 3 && b == 1 ) return true;
	
	return false;
}*/

#endif
