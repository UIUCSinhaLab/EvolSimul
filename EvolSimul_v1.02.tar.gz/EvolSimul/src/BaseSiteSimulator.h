#ifndef BASE_SITE_SIMULATOR_H
#define BASE_SITE_SIMULATOR_H

#include <string>
#include "EvolModels.h"
#include "Motif.h"

/* BaseSiteSimulator class */
class BaseSiteSimulator {
protected:
	// random number generator
	const gsl_rng* rng;	
	
	// simulation results
	vector< pair< double, double > > simulatedPairs; // energy of ancestor and descendent sites
public:
	// constructor
	BaseSiteSimulator(const gsl_rng* _rng);
	
	// access methods
	const vector< pair< double, double > >& getSimulatedPairs() const { return simulatedPairs; }

	// frequencies of the site patterns in the simulation results
	// freqs( i, j ): the frequency of pattern (i, j) where i, j = 0 or 1
	Matrix patternFreq( double energyThr );	
	
	// show the simulation results
	void show() const;
};

#endif
