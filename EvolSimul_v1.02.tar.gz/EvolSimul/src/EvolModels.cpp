#include <algorithm>
#include <gsl/gsl_math.h>
#include <gsl/gsl_eigen.h>

#include "EvolModels.h"

SubstModel::SubstModel() : rateMatrix( 4, 4 ), pi( 4 ), eigenvalues(), U(), invU()
{
}

SubstModel::SubstModel( const vector< double >& _pi ) : rateMatrix( 4, 4 ), pi( _pi ), eigenvalues(), U(), invU()
{
	assert( isPmf( pi ) );
}

SubstModel::SubstModel( const Matrix& _rateMatrix, const vector< double >& _pi ) : rateMatrix( _rateMatrix ), pi( _pi ), eigenvalues(), U(), invU()
{
	assert( rateMatrix.getRows() == 4 && rateMatrix.getCols() == 4 && pi.size() == 4 && isPmf( pi ) );
}

double SubstModel::getRate() const
{
	double result = 0;
	for ( int i = 0; i < NBASES; i++ ) {
		result += pi[ i ] * -rateMatrix( i, i );
	}
	return result;
}

// SubstModel: compute the eigenvalues and eigenvectors of the rate matrix 
// From "Computational Molecular Evolution", Yang, p69
void SubstModel::diagonalize()
{
	// if already computed, return
	if ( eigenvalues.size() ) return;
	
	// find the real symmetric matrix (B) that is similar to the rate matrix
	vector< double > sqrtPi;
	vector< double > invSqrtPi;
	for ( int i = 0; i < 4; i++ ) {
		sqrtPi.push_back( sqrt( pi[ i ] ) );
		invSqrtPi.push_back( 1.0 / sqrt( pi[ i ] ) );
	}
	Matrix sqrtPiMatrix; sqrtPiMatrix.setDiagonalMatrix( sqrtPi );
	Matrix invSqrtPiMatrix; invSqrtPiMatrix.setDiagonalMatrix( invSqrtPi );
	//cout << "sqrtPiMatrix = " << endl; cout << sqrtPiMatrix;
	//cout << "invSqrtPiMatrix = " << endl; cout << invSqrtPiMatrix;
	Matrix B = sqrtPiMatrix * rateMatrix * invSqrtPiMatrix;
	//cout << "B = " << endl; cout << B;
	
	// compute eigenvalues and eigenvectors of B		
	gsl_eigen_symmv_workspace* w = gsl_eigen_symmv_alloc( 4 );
	gsl_vector* eval = gsl_vector_alloc( 4 );		// eigenvalues
	gsl_matrix* evec = gsl_matrix_alloc( 4, 4 );	// eigenvectors (one column per eigenvector)
	gsl_eigen_symmv( B.getData(), eval, evec, w );
	gsl_eigen_symmv_free( w );
	
	// show the eigenvalues and eigenvectors
	//cout << "Eigenvalue\tEigenvector" << endl;
	//for ( int i = 0; i < 4; i++ ) {
	//	cout << gsl_vector_get( eval, i ) << "\t( ";
	//	for ( int j = 0; j < 4; j++ ) {
	//		cout << gsl_matrix_get( evec, j, i ) << " ";	
	//	}
	//	cout << ")" << endl;
	//}
	// diagonalization of B
	for ( int i = 0; i < 4; i++ ) eigenvalues.push_back( gsl_vector_get( eval, i ) );
	Matrix R( evec );
	Matrix invR = R.transpose();
	
	// diagonalization of the rate matrix
	U = invSqrtPiMatrix * R;
	invU = invR * sqrtPiMatrix;

	// free the memory
	gsl_vector_free( eval );
	gsl_matrix_free( evec );
}

// SubstModel: compute the transition probability matrix for a given time
Matrix SubstModel::compProbMatrix( double t )
{
	//assert( probMatrix.getRows() == 4 && probMatrix.getCols() == 4 && t > 0 );
	assert( t >= 0 );
	
	if ( t == 0 ) {
		Matrix result;
		result.setIdentityMatrix( NBASES );
		return result;
	}
	
	// if the rate matrix has not been diagonalized, do it
	if ( !eigenvalues.size() ) diagonalize();
	
	Matrix D;
	vector< double > eigenvaluesExpo;
	for ( int i = 0; i < eigenvalues.size(); i++ ) {
		eigenvaluesExpo.push_back( exp( eigenvalues[ i ] * t ) );	
	}
	D.setDiagonalMatrix( eigenvaluesExpo );
	//cout << "U = " << U << "D = " << D << "invU = " << invU;
	return ( U * D * invU );
}

// SubstModel: propose a random change given the current nt.
int SubstModel::randomMove( const gsl_rng* rng, int currNt )
{
	vector< double > rates = rateMatrix.getRow( currNt );
	double totalRate = -rates[ currNt ];
	
	vector< double > p( 4 );
	for ( int i = 0; i < 4; i++ ) {
		if ( i == currNt ) p[ i ] = 0;
		else p[ i ] = rates[ i ] / totalRate;
	}	
	
	return sampleMul( rng, p ); 
}

// show the SubstModel
ostream& operator<<( ostream& os, const SubstModel& model )
{
	os << model.getRateMatrix();
	return os;	
}

// JCModel constructor
JCModel::JCModel( double _rate ) : SubstModel(), rate( _rate )
{
	assert( rate > 0 );
	
	init();
}

// JCModel: initialization
void JCModel::init()
{
	// set the transition rate matrix
	for ( int i = 0; i < 4; i++ ) {
		for ( int j = 0; j < 4; j++ ) {
			if ( i == j ) 
				rateMatrix( i, j ) = -rate;
			else 
				rateMatrix( i, j ) = rate / 3;	
		}	
	}
	
	// set the equilibrium distribution
	for ( int i = 0; i < 4; i++ ) {
		pi[ i ] = 0.25;	
	}
}

// JCModel: compute the transition probability matrix for a given time
Matrix JCModel::compProbMatrix( double t )
{
	Matrix probMatrix( 4, 4 );	
	
	double alpha = rate / 3.0;		// rate of mutation to a different nt.
	double prob = exp( -4 * ( alpha * t ) );
	double probId = 0.25 + 0.75 * prob;
	double probSubst = 0.25 - 0.25 * prob;
	for ( int i = 0; i < 4; i++ ) {
		for ( int j = 0; j < 4; j++ ) {
			if ( i == j ) 
				probMatrix( i, j ) = probId;
			else
				probMatrix( i, j ) = probSubst;
		}
	}	
	
	return probMatrix;
}

// F81Model constructor
F81Model::F81Model( double _rate, const vector< double >& _pi ) : SubstModel( _pi ), rate( _rate )
{
	assert( rate > 0 );

	init();	
}

// F81Model: initialization
void F81Model::init()
{
	// set the transition rate matrix
	for ( int i = 0; i < 4; i++ ) {
		for ( int j = 0; j < 4; j++ ) {
			if ( i == j ) 
				rateMatrix( i, j ) = -rate * ( 1.0 - pi[ i ] );
			else 
				rateMatrix( i, j ) = rate * pi[ j ];	
		}	
	}	
}

// F81Model compute the transition probability matrix for a given time
Matrix F81Model::compProbMatrix( double t ) 
{	
	Matrix probMatrix( 4, 4 );	

	double prob = exp( -rate * t );
	for ( int i = 0; i < 4; i++ ) {
		for ( int j = 0; j < 4; j++ ) {
			if ( i == j ) 
				probMatrix( i, j ) = prob + ( 1 - prob ) * pi[ j ];
			else	
				probMatrix( i, j ) = ( 1 - prob ) * pi[ j ];
		}
	}
	
	return probMatrix;
}

// HKYModel constructor
HKYModel::HKYModel( double _alpha, double _beta, const vector< double >& _pi ) : SubstModel( _pi ), alpha( _alpha ), beta( _beta ) 
{
	assert( alpha > 0 && beta > 0 );
	
	init();
}

// HKYModel constructor: alternative parameterization
// rate = average rate/site, bias = transition/transversion bias
HKYModel::HKYModel( const vector< double >& _pi, double rate, double bias ) : SubstModel( _pi )
{
	assert( rate > 0 && bias > 0 );
	
	// compute alpha and beta
	double pi_R = pi[ 0 ] + pi[ 2 ];
	double pi_Y = pi[ 1 ] + pi[ 3 ];
	beta = 0.5 * rate / ( ( pi[ 0 ] * pi[ 2 ] + pi[ 1 ] * pi[ 3 ] ) * bias + pi_Y * pi_R );
	alpha = bias * beta;
	
	init();
}

// HKYModel: initialization
void HKYModel::init()
{
	// set the transition rate matrix: non-diagonal terms
	for ( int i = 0; i < 4; i++ ) {
		for ( int j = 0; j < 4; j++ ) {
			if ( i != j ) {
				if ( isTransition( i, j ) ) 
					rateMatrix( i, j ) = alpha * pi[ j ];
				else	
					rateMatrix( i, j ) = beta * pi[ j ];		
			}
		}
	}
	
	// set the transition rate matrix: diagonal terms
	for ( int i = 0; i < 4; i++ ) {
		double sum = 0;
		for ( int j = 0; j < 4; j++ ) {
			if ( j != i ) sum += rateMatrix( i, j );
		}	
		rateMatrix( i, i ) = -sum;
	}		
}

// HKYModel: compute the eigenvalues and eigenvectors of the rate matrix
/*void HKYModel::diagonalize()
{
	//cout << "HKYModel::diagonalize()" << endl;
	// if already computed, return
	if ( eigenvalues.size() ) return;
	
	// eigenvalues
	double pi_R = pi[ 0 ] + pi[ 1 ], pi_Y = pi[ 2 ] + pi[ 3 ];
	eigenvalues.push_back( 0 );
	eigenvalues.push_back( -beta );
	eigenvalues.push_back( -( pi_Y * alpha + pi_R * beta ) );
	eigenvalues.push_back( -( pi_R * alpha + pi_Y * beta ) );
	
	// eigenvector matrix U 
	U.setDimensions( 4 , 4 );
	U( 0, 0 ) = 1; 		U( 0, 1 ) = 1.0 / pi_R;		U( 0, 2 ) = 0;					U( 0, 3 ) = pi[ 1 ] / pi_R;
	U( 1, 0 ) = 1; 		U( 1, 1 ) = 1.0 / pi_R;		U( 1, 2 ) = 0;					U( 1, 3 ) = -pi[ 0 ] / pi_R;
	U( 2, 0 ) = 1; 		U( 2, 1 ) = -1.0 / pi_Y;	U( 2, 2 ) = pi[ 3 ] / pi_Y;		U( 2, 3 ) = 0;
	U( 3, 0 ) = 1;		U( 3, 1 ) = -1.0 / pi_Y;	U( 3, 2 ) = -pi[ 2 ] / pi_Y;	U( 3, 3 ) = 0;
	
	// inverse of U
	invU.setDimensions( 4, 4 );
	invU( 0, 0 ) = pi[ 0 ];			invU( 0, 1 ) = pi[ 1 ]; 		invU( 0, 2 ) = pi[ 2 ];			invU( 0, 3 ) = pi[ 3 ];
	invU( 1, 0 ) = pi[ 0 ] * pi_Y;	invU( 1, 1 ) = pi[ 1 ] * pi_Y;	invU( 1, 2 ) = -pi[ 2 ] * pi_R;	invU( 1, 3 ) = -pi[ 3 ] * pi_R;
	invU( 2, 0 ) = 0; 				invU( 2, 1 ) = 0;				invU( 2, 2 ) = 1.0;				invU( 2, 3 ) = -1.0;
	invU( 3, 0 ) = 1.0;				invU( 3, 1 ) = -1.0;			invU( 3, 2 ) = 0;				invU( 3, 3 ) = 0;		
}*/

// HKYModel: compute the transition probability matrix for a given time
Matrix HKYModel::compProbMatrix( double t ) 
{	
	Matrix probMatrix( 4, 4 );	

	double pi_R = pi[ 0 ] + pi[ 2 ], pi_Y = pi[ 1 ] + pi[ 3 ];
	double e2 = exp( - beta * t );
	double e3 = exp( -( pi_R * alpha + pi_Y * beta ) * t );
	double e4 = exp( -( pi_Y * alpha + pi_R * beta ) * t );
	
	// A
	probMatrix( 0, 0 ) = pi[ 0 ] + e2 * pi[ 0 ] * pi_Y / pi_R + e3 * pi[ 2 ] / pi_R;
	probMatrix( 0, 1 ) = pi[ 1 ] * ( 1 - e2 );	
	probMatrix( 0, 2 ) = pi[ 2 ] + e2 * pi[ 2 ] * pi_Y / pi_R - e3 * pi[ 2 ] / pi_R;
	probMatrix( 0, 3 ) = pi[ 3 ] * ( 1 - e2 );

	// C
	probMatrix( 1, 0 ) = pi[ 0 ] * ( 1 - e2 );
	probMatrix( 1, 1 ) = pi[ 1 ] + e2 * pi[ 1 ] * pi_R / pi_Y + e4 * pi[ 3 ] / pi_Y;	
	probMatrix( 1, 2 ) = pi[ 2 ] * ( 1 - e2 );
	probMatrix( 1, 3 ) = pi[ 3 ] + e2 * pi[ 3 ] * pi_R / pi_Y - e4 * pi[ 3 ] / pi_Y;
		
	// G
	probMatrix( 2, 0 ) = pi[ 0 ] + e2 * pi[ 0 ] * pi_Y / pi_R - e3 * pi[ 0 ] / pi_R;
	probMatrix( 2, 1 ) = pi[ 1 ] * ( 1 - e2 );	
	probMatrix( 2, 2 ) = pi[ 2 ] + e2 * pi[ 2 ] * pi_Y / pi_R + e3 * pi[ 0 ] / pi_R;
	probMatrix( 2, 3 ) = pi[ 3 ] * ( 1 - e2 );
			
	// T
	probMatrix( 3, 0 ) = pi[ 0 ] * ( 1 - e2 );
	probMatrix( 3, 1 ) = pi[ 1 ] + e2 * pi[ 1 ] * pi_R / pi_Y - e4 * pi[ 1 ] / pi_Y;	
	probMatrix( 3, 2 ) = pi[ 2 ] * ( 1 - e2 );
	probMatrix( 3, 3 ) = pi[ 3 ] + e2 * pi[ 3 ] * pi_R / pi_Y + e4 * pi[ 1 ] / pi_Y;
	
	return probMatrix;
}


// HBModel constructor
HBModel::HBModel( const vector< double >& _pi, const Matrix& _neutRateMatrix ) : SubstModel( _pi ), neutRateMatrix( _neutRateMatrix )
{
	// check data
	assert( neutRateMatrix.getRows() == 4 && neutRateMatrix.getCols() == 4 );
	
	// set the transition rate matrix: non-diagonal terms
	for ( int a = 0; a < 4; a++ ) {
		for ( int b = 0; b < 4; b++ ) {
			if ( a != b ) {
				double temp = ( pi[ b ] * neutRateMatrix( b, a ) ) / ( pi[ a ] * neutRateMatrix( a, b ) );
				if ( abs( temp - 1.0 ) > numeric_limits< double >::epsilon() ) rateMatrix( a, b ) = neutRateMatrix( a, b ) * log( temp ) / ( 1.0 - 1.0 / temp );
				else rateMatrix( a, b ) = neutRateMatrix( a, b );
			}
		}
	}
	
	// set the transition rate matrix: diagonal terms
	for ( int a = 0; a < 4; a++ ) {
		double sum = 0;
		for ( int b = 0; b < 4; b++ ) {
			if ( b != a ) sum += rateMatrix( a, b );
		}	
		rateMatrix( a, a ) = -sum;
	}		
}

// TimeParam constructor
TimeParam::TimeParam( double _t1, double _t2, double _delta_t ) : t1( _t1 ), t2( _t2 ), delta_t( _delta_t )
{
	assert( t1 > 0 && t2 > 0 && delta_t > 0 );
	
	n1 = (int)trunc( t1 / delta_t );
	n2 = (int)trunc( t2 / delta_t );
	n = n1 + n2;
}

int EvolData::maxLength = 20;

// EvolData constructor
EvolData::EvolData( const TimeParam& _tp, const vector< double >& _pi, double _rate, double _bias, double _lambda, double _mu, double _r, double _weight ) : tp( _tp ), pi( _pi ), rate( _rate ), bias( _bias ), lambda( _lambda ), mu( _mu ), r( _r ), weight( _weight ), transProbs( tp.n + 1, Matrix( 4, 4 ) ), log_transProbs( tp.n + 1, Matrix( 4, 4 ) ), probs( tp.n + 1, Matrix( 4, 4 ) ), log_probs( tp.n + 1, Matrix( 4, 4 ) ), log_ins_probs( tp.n + 1 ), log_del_probs( tp.n + 1 ), no_indel_probs( tp.n + 1 ), log_no_indel_probs( tp.n + 1 ), weightPowers( maxLength )
{	
	//cout << "Start EvolData" << endl;
	assert( isPmf( pi ) );
	assert( rate > 0 && bias > 0 );
	assert( lambda > 0 && mu > 0 && r > 0 );
	assert( weight >= 0 && weight <= 1.0 );
	assert( ( lambda + mu ) * ( tp.t1 + tp.t2 ) < 1.0 );
							
	// compute equilibrium probabilities
	for ( int i = 0; i < pi.size(); i++ ) {
		log_pi.push_back( log( pi[ i ] ) );	
	}
	
	//cout << "Compute substitution probabilities:" << endl;
	compSubstProbs();
	//cout << "Compute indel probabilities:" << endl;
	compIndelProbs();
	//cout << "Compute weight probabilities:" << endl;	
	compWeightProbs();
}

void EvolData::reset( double _weight )
{
	assert( _weight >= 0 && _weight <= 1.0 );
	weight = _weight;
	compWeightProbs();
}

void EvolData::reset( double _rate, double _lambda, double _mu, double _r )
{
	assert( _rate > 0 && _lambda > 0 && _mu > 0 );
	assert( _r >= 0 && _r <= 1 );
	
	rate = _rate; lambda = _lambda; mu = _mu; r = _r;
	compSubstProbs();
	compIndelProbs();
}

void EvolData::reset( double _weight, double _rate, double _lambda, double _mu, double _r )
{
	reset( _weight );
	reset( _rate, _lambda, _mu, _r );	
}
	
// EvolData: output
ostream& operator<<( ostream& os, const EvolData& ed )
{
	IO_Ctrl::vector_delimiter = "\t";
	
	// parameters
	os << "rate = " << ed.rate << endl;
	os << "lambda = " << ed.lambda << "\tmu = " << ed.mu << "\tr = " << ed.r << endl;
	
	// equlibrium distribution
	os << endl << "log( pi ) = " << ed.log_pi << endl;
	
	// substitution probabilities
	os << endl;
	for ( int i = 0; i <= ed.tp.n; ++i ) {
		os << "t = " << i * ed.tp.delta_t << endl;
		os << "P( t ) = " << endl << ed.transProbs[ i ] << endl;
		os << "log( P( t ) ) = " << endl << ed.log_transProbs[ i ] << endl;
		os << "P( a, b | t ), for all a, b = " << endl << ed.probs[ i ] << endl;
		os << "log( P( a, b |t ) ) for all a, b = " << endl << ed.log_probs[ i ] << endl;
	}
	
	// indel probabilities
	os << endl;
	os << "log( r ) = " << ed.log_r << "\tlog( 1 - r ) = " << ed.log_r_compl << endl;
	for ( int i = 0; i <= ed.tp.n; ++i ) {
		os << "t = " << i * ed.tp.delta_t << endl;
		os << "log( lambda * t ) = ";
		if ( i == 0 ) os << "-inf" << endl;
		else os << ed.log_ins_probs[ i ] << endl;
		os << "log( mu * t ) = ";
		if ( i == 0 ) os << "-inf" << endl;
		else os << ed.log_del_probs[ i ] << endl;
		os << "1 - lambda * t - mu * t = " << ed.no_indel_probs[ i ] << endl;
		os << "log( 1 - lambda * t - mu * t ) = " << ed.log_no_indel_probs[ i ] << endl;
	}
	os << endl;
	os << "log( lambda * t1 + mu * t2 ), for all t1, t2 = " << endl << ed.log_indel_probs << endl;
	os << "log( 1 - lambda * t1 - mu * t2 ), for all t1, t2 = " << endl << ed.log_indel_probs_compl << endl;
	
	return os;
}
	
void EvolData::compSubstProbs()
{
	int n = tp.n;
	double delta_t = tp.delta_t;

	//if ( model ) { cout << "EvolData: deleting" << endl; delete model; }
	SubstModel* model = new HKYModel( pi, rate, bias );
	assert( model != NULL );
	rateMatrix = model->getRateMatrix();
	
	// compute substitution probabilities
	for ( int i = 0; i <= n; i++ ) {
		double t = i * delta_t;

		// transition probabilities
		Matrix P = model->compProbMatrix( t );		
		transProbs[ i ] = P;
		log_transProbs[ i ] = log( P );
		
		// joint probabilities
		Matrix R( NBASES, NBASES );
		for ( int a = 0; a < NBASES; a++ ) {
			for ( int b = 0; b < NBASES; b++ ) {
				R( a, b ) = pi[ a ] * P( a, b );
			}	
		}
		probs[ i ] = R;
		log_probs[ i ] = log( R );	
	}
	
	delete model;	
}

void EvolData::compIndelProbs()
{
	int n = tp.n;
	double delta_t = tp.delta_t;
	
	// compute indel probabilities	
	log_r = log( r );
	log_r_compl = log( 1 - r );
	for ( int i = 0; i <= n; i++ ) {
		double t = i * delta_t;
		
		// insertion probabilities
		if ( i == 0 ) log_ins_probs[ i ] = GSL_NEGINF;
		else log_ins_probs[ i ] = log( lambda * t );
		
		// deletion probabilities
		if ( i == 0 ) log_del_probs[ i ] = GSL_NEGINF;
		else log_del_probs[ i ] = log( mu * t );
		
		// no-indel (matching) probabilities
		no_indel_probs[ i ] = 1 - lambda * t - mu * t;
		log_no_indel_probs[ i ] = log( 1 - lambda * t - mu * t );
	}
	int n_max = max( tp.n1, tp.n2 );
	log_indel_probs.setDimensions( n_max + 1, n_max + 1 );
	log_indel_probs_compl.setDimensions( n_max + 1, n_max + 1 );
	for ( int i = 0; i <= n_max; i++ ) {
		for ( int j = 0; j <= n_max; j++ ) {
			double tuo1 = i * delta_t;
			double tuo2 = j * delta_t;
			
			// indel probabilities
			if ( i == 0 && j == 0 ) log_indel_probs( i, j ) = GSL_NEGINF;
			else log_indel_probs( i, j ) = log( lambda * tuo1 + mu * tuo2 );
			
			// matching probabilites (for partial branches)		
			log_indel_probs_compl( i, j ) = log( 1 - lambda * tuo1 - mu * tuo2 );
		}	
	}	
}

void EvolData::compWeightProbs()
{
	// compute power of weights
	log_weight = log( weight );
	if ( weight <= 1.0 ) {
		double power = 1.0;
		weightPowers[ 0 ] = 1.0;
		
		for ( int i = 1; i < maxLength; ++i ) {
			power *= weight;
			weightPowers[ i ] = power;
		}
	}	
}
