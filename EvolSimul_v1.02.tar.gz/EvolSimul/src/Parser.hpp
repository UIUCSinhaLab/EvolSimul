#include <iostream>
#include <fstream>
#include <map>
#include <sstream>
#include <vector>

using namespace std;


class Dictionary {

	public:
		//Dictionary() {data = new map<string,string>; }
		void clear() { data.clear(); }
		void add(string name, string value){ data[name]=value; }

        // test if a parameter is found
        bool contains( string name ) const {
            return data.count( name ); 
        }
	
		bool checkNameExists(string name);
		string getStringFor(string name);
		double getDoubleFor(string name);
		bool getBoolFor(string name);
		int getIntFor(string name);
		void stringToVector(vector<double> &result, string name);


	private:
		map<string,string> data;
};



class Parser {

	public:
		int parseFile (string fileName, Dictionary& dict);

	
	private:


};



