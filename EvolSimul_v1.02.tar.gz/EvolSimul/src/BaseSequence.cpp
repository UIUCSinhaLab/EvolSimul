#include "BaseSequence.h"

// test if a is an extended symbol (N, Y, R)
bool isExtendedSymbol( int a )
{
	if ( a >= 0 && a < ALPHABET_SIZE && a != GAP ) 
		return true;
	else
		return false;
}

// test if a is a nt. or an extended symbol
bool isNtOrExtended( int a )
{
	return ( a >= 0 && a < ALPHABET_SIZE && a != GAP);	
}

// test if a -> b is transition or transversion where a, b are nts.
bool isTransition( int a, int b )
{
	assert( isNt( a ) && isNt( b ) && a != b );
	
	if ( a == 0 && b == 2 ) return true;
	if ( a == 2 && b == 0 ) return true;
	if ( a == 1 && b == 3 ) return true;
	if ( a == 3 && b == 1 ) return true;
	
	return false;
}

vector< double > createDistr( double GC_content )
{
	vector< double > result( 4 );
	result[ 0 ] = ( 1.0 - GC_content ) / 2;
	result[ 1 ] = GC_content / 2;
	result[ 2 ] = result[ 1 ];
	result[ 3 ] = result[ 0 ]; 
	
	return result;
}

int alnState( int x, int y )
{
	if ( x != GAP ) {
		if ( y != GAP ) return 0;
		else return 1; 	
	} else {
		if ( y != GAP ) return 2;
		else return RET_ERROR;
	}
}

BaseSequence::BaseSequence( const vector< int >& _nts ) : nts( _nts )
{
	// check the BaseSequence 
	for ( int i = 0; i < nts.size(); i++ ) {
		assert( nts[ i ] >= 0 && nts[ i ] < ALPHABET_SIZE );
	}	
}

bool BaseSequence::containsGap() const
{
	for ( int i = 0; i < nts.size(); i++ ) {
		if ( nts[ i ] == GAP ) return true;
	}	
	
	return false;
}

// information of the BaseSequence
void BaseSequence::getNtCounts( vector< int >& counts ) const
{
	counts.clear();
	for ( int i = 0; i < NBASES; i++ ) {
		counts.push_back( 0 );
	}
	
	for ( int i = 0; i < nts.size(); i++ ) {
		if ( nts[ i ] != GAP ) counts[ nts[ i ] ]++;	
	}
}

// insert a nt. at the end of BaseSequence
int BaseSequence::push_back( int nt )
{	
	assert( nt >= 0 && nt < ALPHABET_SIZE );
	nts.push_back( nt );
}


