 /*****************************************************
* Scanning a sequence for matches to PWMs
* Input: sequence, motifs
* Output: matched sites
* File formats: 
* (1) Sequence: .fasta format
* (2) Motif: stubb format
* (3) Sites: .ann format 
******************************************************/
#include "SeqAnnotator.h"

int main( int argc, char* argv[] )
{
    // command line processing
    string seqFile, motifFile;
    double energyThr = 4.0;    // energy of a site should not be larger than this value 
    for ( int i = 1; i < argc; i++ ) {
        if ( !strcmp( "-s", argv[ i ] ) )
            seqFile = argv[ ++i ];       
        else if ( !strcmp( "-m", argv[ i ] ) )
            motifFile = argv[ ++i ];    
        else if ( !strcmp( "-e", argv[ i ] ) )
            energyThr = atof( argv[ ++i ] );            
    }
    if ( seqFile.empty() || motifFile.empty() ) {
        cerr << "Usage: " << argv[ 0 ] << " -s seqFile -m motifFile [-e energyThr]" << endl;
        exit( 1 );
    }    

    int rval;
    
    // read the sequences
    vector< Sequence > seqs;
    vector< string > seqNames;
    rval = readSequences( seqFile, seqs, seqNames );
    assert( rval != RET_ERROR );
    int nSeqs = seqs.size();

    // read the motifs
    vector< Motif > motifs;
    vector< string > motifNames;
    vector< double > background( 4 );
    background[ 0 ] = 0.3; background[ 1 ] = 0.2; background[ 2 ] = 0.2; background[ 3 ] = 0.3;
    rval = readMotifs( motifFile, background, motifs, motifNames ); 
    assert( rval != RET_ERROR );
    int nFactors = motifs.size();
//     for ( int i = 0; i < motifs.size(); i++ ) cout << motifs[i] << endl;

    // factor name to index mapping
    map< string, int > factorIdxMap;
    for ( int i = 0; i < motifNames.size(); i++ ) {
        factorIdxMap[motifNames[i]] = i;
    }

    // scan the sequence
    vector< double > energyThrs( nFactors, energyThr );    
    vector< SiteVec > seqSites( seqs.size() );
    SeqAnnotator ann( motifs, energyThrs );
    for ( int i = 0; i < seqs.size(); i++ ) {
        ann.annot( seqs[ i ], seqSites[ i ] );		
    }

    // print the results
    for ( int i = 0; i < seqSites.size(); i++ ) {
        cout << ">" << seqNames[i] << "\t" << seqSites[i].size() << endl;
        for ( int j = 0; j < seqSites[i].size(); j++ ) {
            Site site = seqSites[i][j];
            char strandChar = site.strand ? '+' : '-';
            cout << site.start + 1 << "\t" << strandChar << "\t" << motifNames[site.factorIdx] << "\t" << site.energy << endl;
        }
    }
    
    return 0;
}
