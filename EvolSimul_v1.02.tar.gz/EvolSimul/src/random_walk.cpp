#include "RandomWalk.h"
#include "Parser.hpp"

int main( int argc, char* argv[] )
{

	if (argc != 3){
	  cerr << "Error, wrong number of parameters. Usage: "<< argv[0] << "configfile numWalks" << endl;
	  exit(1);
	}

	Parser parser;
	Dictionary params;
	int rval = parser.parseFile(argv[1], params);
	int numWalks = atoi(argv[2]);
	
	//Input files
	string seqFile = params.getStringFor("initial_sequence_file");
	string exprFile = params.getStringFor("expression_file");
	string motifFile = params.getStringFor("motif_file");
	string factorExprFile = params.getStringFor("factor_expr_file");
	string factorInfoFile = params.getStringFor("factor_info_file");
	string coopFile = params.getStringFor("cooperation_file");
	string repressionFile = params.getStringFor("repression_file");
	
	ModelType modelOption = getModelOption(params.getStringFor("model_option"));

	// additional control parameters of the expression model
	double gcContent = params.getDoubleFor("gcContent");
	double energyThr = params.getDoubleFor("energyThr");
	double coopDistThr = params.getDoubleFor("coopDistThr");
	double repressionDistThr = params.getDoubleFor("repressionDistThr");; 
	int maxContact = params.getIntFor("maxContact");
	double basalTxp = params.getDoubleFor("basalTxp");
	
	
	// evolutionary parameters
	int N = params.getIntFor("population_size");
	double mu = params.getDoubleFor("mutation_rate");
	int cycleLength = params.getIntFor("num_generations");
	EvolSimulator::printTime = params.getIntFor("print_time");
	EvolSimulator::printProb = params.getDoubleFor("print_prob");
	if (EvolSimulator::printTime == -1)
		EvolSimulator::printTime = cycleLength/10;

	// optional evolutionary parameters: indels
	double substitution_probability = params.getDoubleFor("substitution_probability");
	double insertion_probability = params.getDoubleFor("insertion_probability");
	double expectedIndelLength = params.getDoubleFor("expected_indel_length");

	//Fitness function parameters
	FitnessFunc::D_max = params.getDoubleFor("D_max");   
	FitnessFunc::selectionExp = params.getDoubleFor("selectionExp");

	if ( motifFile.empty() || factorExprFile.empty() || factorInfoFile.empty() || ( modelOption == QUENCHING && repressionFile.empty() ) 
			|| seqFile.empty() || exprFile.empty() ) {
		cerr << "Bad configuration file.\n";
		exit( 1 );
	}


	string factor1, factor2;    // buffer for reading factor pairs
	
	// read the motifs
	vector< Motif > motifs;
	vector< string > motifNames;
	vector< double > background = createNtDistr( gcContent );
	rval = readMotifs( motifFile, background, motifs, motifNames ); 
	assert( rval != RET_ERROR );
	int nFactors = motifs.size();

	// factor name to index mapping
	map< string, int > factorIdxMap;
	for ( int i = 0; i < motifNames.size(); i++ ) {
		factorIdxMap[motifNames[i]] = i;
	}

	// read TF information: binding, activation and repression
	ifstream finfo( factorInfoFile.c_str() );
	if ( !finfo ) {
		cerr << "Cannot open the factor information file " << factorInfoFile << endl;
		exit( 1 );
	}
	vector< double > maxBindingWts( nFactors );
	vector< double > txpEffects( nFactors );
	vector< double > repEffects( nFactors );
	string name;
	double effect;
	int i = 0;
	while ( finfo >> name >> maxBindingWts[i] >> effect >> repEffects[i] ) {
		assert( name == motifNames[i] );
		if ( modelOption == LOGISTIC ) txpEffects[i] = exp( effect );
		else txpEffects[i] = effect;
		i++;
	}
	vector< bool > actIndicators( nFactors, false );
	vector< bool > repIndicators( nFactors, false );
	for ( int i = 0; i < nFactors; i++ ) {
		if ( txpEffects[i] > 0.0 ) actIndicators[i] = true;
		if ( repEffects[i] > 0.0 ) repIndicators[i] = true; 
	}

	// read the cooperativity matrix    
	Matrix factorIntMat( nFactors, nFactors, 1.0 );
	if ( !coopFile.empty() ) {
		ifstream fcoop( coopFile.c_str() );
		if ( !fcoop ) {
			cerr << "Cannot open the cooperativity file " << coopFile << endl;
			exit( 1 );
		}  
		double coopVal;
		while ( fcoop >> factor1 >> factor2 >> coopVal ) {
			assert( factorIdxMap.count( factor1 ) && factorIdxMap.count( factor2 ) );
			int idx1 = factorIdxMap[factor1];
			int idx2 = factorIdxMap[factor2];
			factorIntMat( idx1, idx2 ) = coopVal;
		}        
	}         

	// read the repression matrix 
	IntMatrix repressionMat( nFactors, nFactors, false );
	if ( !repressionFile.empty() ) {
		ifstream frepr( repressionFile.c_str() );
		if ( !frepr ) {
			cerr << "Cannot open the repression file " << repressionFile << endl;
			exit( 1 );
		}        
		while ( frepr >> factor1 >> factor2 ) {
			assert( factorIdxMap.count( factor1 ) && factorIdxMap.count( factor2 ) );
			int idx1 = factorIdxMap[factor1];
			int idx2 = factorIdxMap[factor2];
			repressionMat( idx1, idx2 ) = true;
		}        
	}    

	// create the ExprFunc object
	ExprPar::modelOption = modelOption;
	ExprFunc::modelOption = modelOption;
	FactorIntFunc* intFunc = new FactorIntFuncBinary( coopDistThr );
	ExprPar par( maxBindingWts, factorIntMat, txpEffects, repEffects, basalTxp);
	ExprFunc* func = new ExprFunc( motifs, intFunc, actIndicators, maxContact, repIndicators, repressionMat, repressionDistThr, par );

	// read TF expression
	vector< vector< double > > data;
	vector< string > labels;
	vector< string > condNames;  
	rval = readMatrix( factorExprFile, labels, condNames, data );
	assert( rval != RET_ERROR );
	assert( labels.size() == nFactors );
	for ( int i = 0; i < nFactors; i++ ) assert( labels[i] == motifNames[i] );
	Matrix factorExprData( data ); 
	int nConds = factorExprData.nCols();

	// create the Environment
	Environment env( factorExprData );

	// read the evolutionary target
	data.clear();
	labels.clear();
	rval = readMatrix( exprFile, labels, data );
	assert( rval != RET_ERROR );
	Matrix exprData( data ); 
	assert( exprData.nRows() == 1 );
	Phenotype P_target( exprData.getRow( 0 ) );

	// random number generator
	gsl_rng_env_setup();
	const gsl_rng_type * T = gsl_rng_default;	// create rng type
	gsl_rng* rng = gsl_rng_alloc( T );
	gsl_rng_set( rng, time( 0 ) );		// set the seed equal to simulTime(0)    

	// create the simulator
	vector< double > energyThrs( nFactors, energyThr );
	RandomWalk simulator( rng, func, energyThrs, env, P_target );
	if (substitution_probability != 0)
		simulator.setIndelParameters(substitution_probability, insertion_probability, expectedIndelLength);

	// initialize the population
	vector< Sequence > seqs;
	vector< string > seqNames;
	rval = readSequences( seqFile, seqs, seqNames );
	assert( rval != RET_ERROR );
	assert( seqs.size() == 1 );
	for (int i=0; i<numWalks; i++) {
	  Sequence initSeq = seqs[0];
	  simulator.initialize( initSeq );

	  // evolve the population and report the results
	  simulator.walk( cycleLength );
	  cout << endl;
	}

	return 0;
}


