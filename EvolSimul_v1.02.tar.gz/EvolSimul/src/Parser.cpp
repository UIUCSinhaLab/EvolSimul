#include "Parser.hpp"
// this file was added by TD

int Parser::parseFile(string fileName, Dictionary& dict){
	dict.clear();

	ifstream in( fileName.c_str(), ifstream::in );
	if(!in) {
		cerr << "Error: could not open configuration file\n";
		exit(-1);
	}

    string line;
	while ( !in.eof() ){
        getline( in, line );
        if ( line[0] == '#' || line.empty() ) continue;
        stringstream ss( line, stringstream::in );
		string name, value;
		ss >> name >> value;
		dict.add(name, value);
	}

	return 0;
}

bool Dictionary::checkNameExists(string name) {
	map<string,string>::iterator pos;
	pos = data.find(name);
	return pos != data.end();
}
	
string Dictionary::getStringFor (string name){

	map<string,string>::iterator pos;
	pos = data.find(name);
	if (pos != data.end() ) {
		if (pos->second == "NULL")
			return "";
		else
			return pos->second;
	}
	else {
		cerr << "Error: Parameter " << name << " not defined in configuration file\n";
	}
	return "";
}

double Dictionary::getDoubleFor (string name){

	map<string,string>::iterator pos;
	pos = data.find(name);
	if (pos != data.end()) {
		return strtod(pos->second.c_str(), NULL);
	}
	else {
		cerr << "Warning: Parameter " << name << " not defined in configuration file\n";
	}
	return 0;
}


bool Dictionary::getBoolFor (string name){

	map<string,string>::iterator pos;
	pos = data.find(name);
	if (pos != data.end()) {
		if (pos->second == "true" || pos->second == "True")
			return true;
	}
	else {
		//cerr << "Error: Parameter " << name << " not defined in configuration file\n";
	}
	return false;

}

int Dictionary::getIntFor(string name){
	
	map<string,string>::iterator pos;
	pos = data.find(name);
	if (pos != data.end()) {
		return (int) strtol(pos->second.c_str(), NULL, 10);
	}
	else {
		cerr << "Error: Parameter " << name << " not defined in configuration file\n";
	}
	return 0;
}

void Dictionary::stringToVector(vector<double> &result, string name) {
	
	string encoded = getStringFor(name);
	string sep = ",";
	int MAX_STRING = 1000;
	char buffer[ MAX_STRING ];
	strcpy( buffer, encoded.c_str() );
	char* token;
	token = strtok( buffer, sep.c_str() );
	while ( token ) {
		result.push_back(strtod(token, NULL));
		token = strtok( NULL, sep.c_str() );
	}
}
