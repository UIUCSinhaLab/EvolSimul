#ifndef MOTIF_H
#define MOTIF_H
#include <cctype>
#include <cstring>
#include <string>
#include <utility>

#include "Tools.h"
#include "SeqAnnotator.h"
#include "BaseSequence.h"

/*****************************************************
* Sequence Elements
******************************************************/

/* SeqElement class */
class SeqElement : public BaseSequence {
public:
	// constructor
	SeqElement() : BaseSequence() {}
	SeqElement( const vector< int >& _nts ) : BaseSequence( _nts ) {}
	SeqElement( const Sequence& seq, int start, int length );
	void copy( const SeqElement& other ) { nts = other.nts; }
	SeqElement( const SeqElement& other ) { copy( other ); }

	// assignment
	SeqElement& operator=( const SeqElement& other ) { copy( other ); return *this; }
	
	// equality test
	bool operator==( const SeqElement& other ) const { return nts == other.nts; }
			
	// insert a nt. at the end of sequence
	int push_back( int nt );

	// remove gaps, i.e. restore the sequence element
	SeqElement restoreElem() const; 

	// reverse complement of a sequence element
	SeqElement compRevCompl() const;
		
	// compute the log-likelihood of generating this sequence element with some distribution
	double comp_ll( const vector< double >& pi ) const;
	
	// output
	friend ostream& operator<<( ostream& os, const SeqElement& elem );	
};

/*****************************************************
* DNA Sequence Motifs
******************************************************/

/* TfbsMotif class: transcription factor binding site motif, adding energy computation */
class TfbsMotif : public Motif {
	// background distribution
	vector< double > background;
	
	// energy matrix, defined as: E(i,a) = energy of nt. a at position i
	Matrix energyMat;
public:
	// constructors
	TfbsMotif() : Motif(), energyComputed( false ) {}
	TfbsMotif( int _length ) : Motif( _length ), energyMat( _length, 4 ), energyComputed( false ) {}	
	TfbsMotif( const Matrix& _pwm, const vector< double >& _background ); 
	TfbsMotif( const Matrix& countMatrix, double pseudoCount, const vector< double >& _background );		// countMatrix in Transfac format
	TfbsMotif( const Motif& motif, const vector<double>& _background);
	void copy( const TfbsMotif& other ) { pwm = other.pwm; background = other.background; energyMat = other.energyMat; }
	TfbsMotif( const TfbsMotif& other ) { copy( other ); }

	// assignment
	TfbsMotif& operator=( const TfbsMotif& other ) { copy( other ); return *this; }
	
	// access methods
	const vector< double >& getBackground() const { return background; }
	const Matrix& getEnergyMat() const { return energyMat; }
	
	// the reverse complement of this motif
	TfbsMotif compRevCompl() const;

	// compute the energy (log-likelihood ratio) of a site 
	double energy( const SeqElement& elem ) const;
	
	// compute the log-likelihood of generating a site 
	double comp_ll( const SeqElement& elem ) const;
	
	// sample a site whose energy is larger than a threshold
	void sampleGoodSite( const gsl_rng* rng, SeqElement& elem, double thr ) const;
	
	// load a TfbsMotif
	int load( const string& file, const vector< double >& background, string& name );
	int load( const string& file, const vector< double >& background );
	
	// output
	friend ostream& operator<<( ostream& os, const TfbsMotif& motif );
private:
	bool energyComputed;	// whether energy matrix has been computed
	void init();	
};

// read the motifs (PWMs) in a FASTA-like format: pseudocounts within the file
int readMotifs( const string& file, vector< Motif >& motifs, vector< string >& names );
int readMotifs( const string& file, vector< Motif >& motifs );
int readMotifs( const string& file, const vector< double >& background, vector< TfbsMotif >& motifs, vector< string >& names );
int readMotifs( const string& file, const vector< double >& background, vector< TfbsMotif >& motifs );



#endif
