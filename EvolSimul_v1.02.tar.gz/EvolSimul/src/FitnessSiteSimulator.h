#ifndef FITNESS_SITE_SIMULATOR_H
#define FITNESS_SITE_SIMULATOR_H

#include <string>
#include "EvolModels.h"
#include "BaseSiteSimulator.h"
#include "EvolSimulator.h"

class FitnessSiteSimulator : public BaseSiteSimulator {
  public: 
	// constructors
	FitnessSiteSimulator(const gsl_rng* _rng,
			double selectionCoeff,
			ExprFunc* _exprFunc, 
			const vector< double >& _energyThrs, 
			const Environment& _env, 
			const Phenotype& _evolTarget,
			const SubstModel* _bgModel);

	// Computes the fitness of a sequence
	double computeFitness(const Sequence& seq) const;

	// evolve a site
	int evolve(const Sequence& ancSeq, int siteStart, 
			   int siteEnd, double t, Sequence& descSeq,
			   TfbsMotif& motif) const;

	// simulate the evolution 
	string simulate(int N, double simulTime, Sequence& ancSeq, 
					int siteStart, int siteEnd, TfbsMotif& motif,
					double* ancientEnergy, double* descendentEnergy,
					double* ancientFitness, double* descendentFitness);

  private: 
	int time;	// the current generation time

	double selectionCoeff;  // The coeficient for selection
	vector< double > energyThrs;     // the energy thresholds for all motifs
	ExprFunc* exprFunc;  // the ExprFunc object, containing the relevant parameters
	Environment env;	// the current environment
	Phenotype evolTarget;	// the evolutionary target
	PhenotypeFunc* phenoFunc;		// genotype-to-phenotype function
	FitnessFunc* fitnessFunc;		// phenotype-to-fitness function
	const SubstModel* bgModel;	// background substitution model (or mutation rate matrix)

};

#endif
