#include <queue>
#include <gsl/gsl_randist.h>
#include "EvolSimulator.h"
#include <time.h> 
#include <stdio.h>

int EvolSimulator::stoppingCriteria;
double EvolSimulator::targetFitness;
double EvolSimulator::adaptationRatio;
int EvolSimulator::tc;
double EvolSimulator::selectionScale;
double EvolSimulator::selectionCoeff;
double EvolSimulator::distanceThreshold;
vector<double> EvolSimulator::printTimesList;

int compDistance( const Sequence& seq1, const Sequence& seq2 )
{
	assert( seq1.size() == seq2.size() ); 

	int dist = 0;
	for ( int i = 0; i < seq1.size(); i++ ) {
		if ( seq1[i] != seq2[i] ) dist++;
	}

	return dist;
}

void SequenceCompact::copy(const SequenceCompact & other){
	indelPositions = other.indelPositions;
	indelLenghts = other.indelLenghts;
	indelSequences = other.indelSequences;
	indelTypes = other.indelTypes;
	length = other.length;
	max_length = other.max_length;
	currentDistance = other.currentDistance;
}


// Calculates a distance, as the number of substitutions divided by size,
// from the reference sequence
void SequenceCompact::calculateDistance() {
	Sequence seq;
	reconstructWithoutIndels(seq);
	int substitutions = 0;

	for (int i = 0; i < seq.size(); i++) {
		if (seq[i] != -1 && seq[i] != refSeq[i]) {
			substitutions++;
		}
	}

	currentDistance =  1.0 * substitutions / refSeq.size();
}


void SequenceCompact::calculateDistanceDeprecated() {
	int substitutions  = 0;
	int deletions = 0;
	int insertions = 0;

	// This will remap positions based on indels
	int position_remap[max_length];
	for (int i = 0; i < max_length; i++) {
		position_remap[i] = 0;
	}

	for ( int i = 0; i < indelPositions.size(); i++){
		if (indelTypes[i] == DELETION) {
			for (int j = indelPositions[i]; j < max_length; j++) {
				position_remap[j] += indelLenghts[i]; 
			}
		} 
		if (indelTypes[i] == INSERTION) {
			for (int j = indelPositions[i]; j < max_length; j++) {
				position_remap[j] -= indelLenghts[i]; 
			}
		} 
		else if (indelTypes[i] == SUBSTITUTION) {
			int position = indelPositions[i] + position_remap[indelPositions[i]];
			if (refSeq[position] != indelSequences[i][0])
				substitutions ++;
		}
	}

	int size = refSeq.size();
	currentDistance = 1.0 * substitutions / size;
}


// Reconstruct a sequence from a list of mutations
void SequenceCompact::reconstructSeq( Sequence& origSeq ) const
{
	origSeq = refSeq;
	//Reconstructs the indels
	for ( int i = 0; i < indelPositions.size(); i++){
		if (indelTypes[i] == INSERTION) {
			origSeq.insertion(indelPositions[i], indelSequences[i]);
			//origSeq.cut(indelLenghts[i], indelPositions[i] < (origSeq.size()/2));
		}
		else if (indelTypes[i] == DELETION) {
			origSeq.deletion(indelPositions[i], indelLenghts[i]);
			//origSeq.insertion(origSeq.size(), indelSequences[i]);
		}
		else {
			origSeq[indelPositions[i]] = indelSequences[i][0];
		}
	}
} 


// Reconstruct the sequence ignoring indels,
// Used to calculated the distance between two sequences with indels.
void SequenceCompact::reconstructWithoutIndels(Sequence& origSeq) const 
{

	origSeq = refSeq;
	vector<Sequence> deletions;
	//Reconstructs the indels
	for ( int i = 0; i < indelPositions.size(); i++){
		if (indelTypes[i] == INSERTION) {
			origSeq.insertion(indelPositions[i], indelSequences[i]);
			//origSeq.cut(indelLenghts[i], indelPositions[i] < (origSeq.size()/2));
		}
		else if (indelTypes[i] == DELETION) {
			Sequence deleted_sequence;
			for (int j = 0; j < indelLenghts[i]; j++) {
				deleted_sequence.push_back(origSeq[indelPositions[i] + j]);
			}
			deletions.push_back(deleted_sequence);
			origSeq.deletion(indelPositions[i], indelLenghts[i]);
		}
		else {
			origSeq[indelPositions[i]] = indelSequences[i][0];
		}
	}

	
	//Removes the indels
	for ( int i = indelPositions.size()-1; i >= 0; i--){
		if (indelTypes[i] == INSERTION) {
			origSeq.deletion(indelPositions[i], indelLenghts[i]);
		}
		else if (indelTypes[i] == DELETION) {
			origSeq.insertion(indelPositions[i], deletions.back());
			deletions.pop_back();
		}
	}

	assert(origSeq.size() == refSeq.size());
}


// Reconstruct the sequence ignoring indels,
// Used to calculated the distance between two sequences with indels.
void SequenceCompact::reconstructGappedAlignment(Sequence& origSeq) const 
{

	origSeq = refSeq;
	//Reconstructs the indels
	for ( int i = 0; i < indelPositions.size(); i++){
		if (indelTypes[i] == INSERTION) {
			origSeq.insertion(indelPositions[i], indelSequences[i]);
			//origSeq.cut(indelLenghts[i], indelPositions[i] < (origSeq.size()/2));
		}
		else if (indelTypes[i] == DELETION) {
			origSeq.deletion(indelPositions[i], indelLenghts[i]);
		}
		else {
			origSeq[indelPositions[i]] = indelSequences[i][0];
		}
	}

	
	//Removes the indels
	for ( int i = indelPositions.size()-1; i >= 0; i--){
		if (indelTypes[i] == INSERTION) {
			origSeq.deletion(indelPositions[i], indelLenghts[i]);
		}
		else if (indelTypes[i] == DELETION) {
			Sequence gap;
			for (int pos = 0; pos < indelLenghts[i]; pos++) {
				gap.push_back(5);
			}
			origSeq.insertion(indelPositions[i], gap);
		}
	}

	assert(origSeq.size() == refSeq.size());
}


void SequenceCompact::addSubstitution(int pos, int newAllele){

	// Create a sequence containing the new allele
	Sequence seq; seq.push_back(newAllele);

	// Checks whether there exists a substitution in that position
	for ( int i = 0; i < indelPositions.size(); i++) {
		if (indelTypes[i] == SUBSTITUTION)
			if (indelPositions[i] == pos) {
				indelSequences[i] = seq;
				calculateDistance();
				return;
			}
	}

	// Creates a new indel of type SUBSTITUTION
	indelPositions.push_back(pos);
	indelLenghts.push_back(0);
	indelTypes.push_back(SUBSTITUTION);
	indelSequences.push_back(seq);
	calculateDistance();
}


// Adds an indel to a sequence.
// this will effectively change the sequence to reflect that indel
void SequenceCompact::addIndel(int pos, int _length, Sequence &seq, int type) {
	indelPositions.push_back(pos);
	indelLenghts.push_back(_length);
	indelTypes.push_back(type);
	indelSequences.push_back(seq);
	length += (type * _length);
	if (type == INSERTION)
		max_length += _length;
	calculateDistance();
}


// Returns the size of a sequence
// reconstructs the sequence to account for indels
// TODO: calculate the size without reconstructing the sequence
int SequenceCompact::size(){
	Sequence seq; 
	reconstructSeq( seq );
	return seq.size();
}


// Writes a sequence to a string
// TODO: implement this
string SequenceCompact::SerializeToString() const {
	string s = "";
}
	

ostream& operator<<( ostream& os, const Phenotype& pheno )
{
	os << pheno.exprProfile;
	return os;
}

void PhenotypeFunc::computePhenotype( const Sequence& seq, Phenotype& pheno ) const
{
	// construct the sequence representation as a vector of binding sites
	SiteVec sites;
	ann->annot( seq, sites );

	// compute the epxression profile 
	int nConds = env.factorExprProfiles.nCols();
	for ( int j = 0; j < nConds; j++ ) {
		vector< double > concs = env.factorExprProfiles.getCol( j );
		double predicted = exprFunc->predictExpr( sites, seq.size(), concs);
		pheno.exprProfile.push_back( predicted );
	}	
}

double FitnessFunc::D_max;   
double FitnessFunc::selectionExp;

double FitnessFunc::computeFitness( const Phenotype& pheno ) const
{

	// compute the RMSE between the phenotype and the target
	double deviation = phenotypeDev( pheno, target );

	// the fitness value is a funciton of RMSE
#if 0
	return pow( ( 1.0 - deviation / D_max ), selectionExp );
#endif

#if 0
	double f = pow( ( 1.0 - deviation ), selectionExp ) + 1E-5; // the additive term avoids 0 at the beginning
	if (f > 1) f = 1;
	return f;
#endif
	double f = pow( ( 1.0 - deviation ), selectionExp ); // 
	return f;
}

double FitnessFunc::phenotypeDev( const Phenotype& pheno1, const Phenotype& pheno2 )
// pheno2 is the target
{
	vector< double > profile1 = pheno1.getExprProfile();
	vector< double > profile2 = pheno2.getExprProfile();
	assert( profile1.size() == profile2.size() );

	double max2 = 0;
	for ( int i = 0; i < profile2.size(); i++ ) {
	  if (profile2[i] > max2) max2 = profile2[i];
	}

	double reward = 0;
	double rewardnorm = 0;
	for ( int i = 0; i < profile2.size(); i++ ) {
	  double p1 = profile1[i]; // prediction
	  double p2 = profile2[i]; // real
	  if (p1 > max2) p1 = max2;

	  double minp12 = p1;
	  if (p2 < minp12) minp12 = p2;

	  reward += p2*minp12;
	  rewardnorm += p2*p2;
	}
	if (rewardnorm > 1e-10) reward /= rewardnorm;
	else reward = 0;

	double penalty = 0;
	double penaltynorm = 0;
	for ( int i = 0; i < profile2.size(); i++ ) {
	  double p1 = profile1[i]; // prediction
	  double p2 = profile2[i]; // real
	  if (p1 > max2) p1 = max2;

	  double diff12 = p1 - p2;
	  if (diff12 < 0) diff12 = 0;

	  penalty += (max2-p2)*diff12;
	  penaltynorm += (max2-p2)*(max2-p2);
	}
	if (penaltynorm > 1e-10) penalty /= penaltynorm;
	else penalty = 0;

	double pgp = reward - penalty;
	if (pgp < 0) pgp = 0;
	assert(pgp >= 0 && pgp <= 1);
	return (1-pgp);

}

int EvolSimulator::printTime = 0;
double EvolSimulator::printProb = 0;

EvolSimulator::EvolSimulator(const gsl_rng* _rng,
		double _mutationRate,
		ExprFunc* _exprFunc,
		const vector< double >& _energyThrs,
		const Environment& _env,
		const Phenotype& _evolTarget,
		SubstModel *_bgModel) : 
				rng( _rng ),
				mutationRate( _mutationRate ),
				exprFunc( _exprFunc ),
				energyThrs( _energyThrs ),
				env( _env ),
				evolTarget( _evolTarget ),
				bgModel(_bgModel),
				time( 0 ),
				substitution_probability(1),
				insertion_probability(0)
{
	assert( rng != NULL ); 
	assert( mutationRate >= 0 );

	phenoFunc = new PhenotypeFunc( exprFunc, energyThrs, env );
	fitnessFunc = new FitnessFunc( evolTarget );

	// Print a header for the debug and tracking info:
	cerr << "#$%\tfitness\ttime\tavgFit\tminFit\tpheno\t%$#\n";
}

void EvolSimulator::setIndelParameters(
		double _substitution_probability,
		double _insertion_probability,
		double _tandem_repeat_probability) {
	
	substitution_probability = _substitution_probability;
	insertion_probability = _insertion_probability;
	tandem_repeat_probability = _tandem_repeat_probability;

}

void EvolSimulator::initialize( int N, const Sequence& initSeq )
{
	refSeq = initSeq;
	time = 1;
	last_print_time = -1;
	int nseqs;

	// initialize the population and the fitness values

	double tF = fitnessFunc->computeFitness( evolTarget );

	SequenceCompact seq( initSeq );
	double fitness = computeFitness( seq );
	
	//If popsize = 1 we have only one sequence
	if (N == 1)
		nseqs = 1;
	//Otherwishe, we have 2 * N sequences;
	else 
		nseqs = 2 * N;

	for ( int i = 0; i < nseqs; i++ ) {
		population.push_back( seq );	
		fitnesses.push_back( fitness );
	}
}

void EvolSimulator::savePredictedExpression (int N, const Sequence& initSeq, string seqName) {

	Phenotype pheno;
	phenoFunc->computePhenotype(initSeq, pheno);

	double f = fitnessFunc->computeFitness( pheno );
	cout << setprecision(30) << seqName << "\t" << pheno << endl;
	cerr << pheno << "\t" << f << endl;
}

int EvolSimulator::insertionLength(){
	if (gsl_rng_uniform(rng) < 0.56374)
		return gsl_ran_geometric(rng, 0.23986);
	else
		return gsl_ran_geometric(rng, 0.082786);
}

int EvolSimulator::deletionLength(){
	if (gsl_rng_uniform(rng) < 0.38518)
		return gsl_ran_geometric(rng, 0.38433);
	else
		return gsl_ran_geometric(rng, 0.10117);

}

// Checks if the average evolutionary distance (measured as the proportion
// of bp with non-synonymous substitutions) is greater than a threshold. 
bool EvolSimulator::checkDistanceStoppinCriteria() {
	return checkDistance(distanceThreshold);
}

bool EvolSimulator::checkDistance(double distanceThreshold) {

	if (distanceThreshold > 1.0) 
		return false;

	double avg_distance = 0.0;
	for (int i = 0; i < population.size(); i++) {	
		avg_distance += population[i].getDistance();
	}
	avg_distance /= population.size();

	cout << avg_distance << endl;
	if (avg_distance > distanceThreshold) {
		return true;
	}
	return false;
}

void EvolSimulator::checkDistanceForPrinting() {
	double distanceThreshold = printTimesList[nextPrintTimeIndex];
	if (checkDistance(distanceThreshold)) {
		char filename[50];
		sprintf(filename, "population.pt%d", nextPrintTimeIndex);
		print(true, string(filename));
		char filename_aligned[50];
		sprintf(filename_aligned, "aligned.pt%d", nextPrintTimeIndex);
		printAligned(true, string(filename_aligned));
		nextPrintTimeIndex++;
	}
}

void EvolSimulator::evolve( int nGenerations, int maxGenerations )
{

	SequenceCompact oldSeq(refSeq); 
	double oldFit;
	int nMutations;

	nextPrintTimeIndex = 0;


	avgFit = 0;
	minFit = 0;
	// 
	int seenAdaptation = 0; // number of generations for which our adaptation criteria is met
	if (maxGenerations <= nGenerations) maxGenerations = nGenerations;
	for ( int t = 0; t < maxGenerations; t++ ) {
		time++;

		// Checks stopping criteria (other than maxGenerations).
		bool stopNow = false;
		if (time > (nGenerations - tc + 1)) { // this would happen if maxGenerations > nGenerations
		                           // Think of nGenerations as the minimun number of generation to run
			
			// if x% have fitness > targetFitness stop 
			if (stoppingCriteria == DEFAULT) {
				if (countFit >= adaptationRatio*population.size()) {
					seenAdaptation++;
				}
				else seenAdaptation = 0;
			}
			// Check the various stopping criteria
			else if (stoppingCriteria == AVG) {
				if (avgFit >= targetFitness) {
					seenAdaptation++;
				}
				else seenAdaptation = 0;
			}
			else if (stoppingCriteria == MIN) {
				if (minFit >= targetFitness) {
					seenAdaptation++;
				}
				else seenAdaptation = 0;
			}
			else if (stoppingCriteria == MAX) {
				if (maxFit >= targetFitness) {
					seenAdaptation++;
				}
				else seenAdaptation = 0;
			}

			// Check if the stopping criteria was met for enough generations
			if (seenAdaptation >= tc) {
				stopNow = true;
			}
		}
		if (checkDistanceStoppinCriteria()) {
			stopNow = true;
		}

		if (stopNow) {
			print(stopNow); // since this variable is true, 
							// a print will be forced 
			break;
		}

		if (population.size() == 1){
			nMutations = 1;
			//Save the population
			oldSeq = population[0];
			oldFit = fitnesses[0];

		}
		else {
			// sample mutations 
			double expectedNumMutations = population.size() * 
					refSeq.size() * mutationRate; 
			nMutations = gsl_ran_poisson( rng, expectedNumMutations );
		}

		doMutations(nMutations);


		if (population.size() == 1){
			if (fitnesses[0] < oldFit){
				population[0] = oldSeq;
				fitnesses[0] = oldFit;
			}
			print();
			continue;
		}


		// selection of individuals for next generation
		vector< int > nextGen;
		sampleNextGeneration( nextGen );

		// update the population: collect the number of offsprings 
		// of each individual
		vector< int > nOffsprings( population.size(), 0 );
		for ( int i = 0; i < nextGen.size(); i++ ) {
			nOffsprings[ nextGen[i] ]++;	
		}

		// update the population: list of the dead individuals
		queue< int > deadInds;
		for ( int i = 0; i < population.size(); i++) {
			if ( nOffsprings[i] == 0 ) deadInds.push( i ); 	
		}

		// update the pupulation: replace the dead individuals
		for ( int i = 0; i < population.size(); i++ ) {
			if ( nOffsprings[i] <= 1 ) continue;
			for ( int j = 0; j < nOffsprings[i] - 1; j++ ) {
				int emptySpace = deadInds.front();
				population[emptySpace] = population[i];
				fitnesses[emptySpace] = fitnesses[i];
				deadInds.pop();
			}	
		} 

		countFit = 0;
		maxFit = 0;
		maxFitId = 0;
		avgFit = 0;
		minFit = 1.0;
		for ( int i = 0; i < population.size(); i++ ) {
			if (fitnesses[i] > targetFitness) countFit++;
			if (fitnesses[i] > maxFit) {
				maxFit = fitnesses[i];
				maxFitId = i;
			}
			if (fitnesses[i] > minFit) {
				minFit = fitnesses[i];
			}
			avgFit = ((avgFit * i) + fitnesses[i]) / (i + 1);
		}

		print();
		checkDistanceForPrinting();
	}
}


void EvolSimulator::doMutations (int nMutations){

	int randInd, randPos;

	if (time > last_print_time) {
		n_printed = 0;
		last_print_time = time;
	}

	for ( int i = 0; i < nMutations; i++ ) {

		int type;
		//Chooses the mutation type: Substitution or indel.
		if (gsl_rng_uniform( rng ) < substitution_probability) { 

			// A substitution

			randInd = gsl_rng_uniform_int( rng, population.size() );
			randPos = gsl_rng_uniform_int( rng, population[randInd].size() );


			/*Debug
			if (time % printTime == 0 || time <= 2) {
			  cerr << time << "\t" << randInd << "\t" << "0" << "\t" << randPos << "\t" << "0";
			  cerr << "\t" << fitnesses[randInd] << "\t-->\t";
			}
			*/

			mutate( population[randInd], randPos );
			fitnesses[randInd] = computeFitness( population[randInd] );
			n_printed++;

			/*Debug
			if (time % printTime == 0 || time <= 2) {
			  cerr << fitnesses[randInd] << endl;
			}
			*/
		}
		else 
		{
			int length;
			if (gsl_rng_uniform(rng) < insertion_probability) {
				//An insertion
				type = INSERTION;
				length = insertionLength();
			}
			else {
				//A deletion
				type = DELETION;
				length = deletionLength();
			}

			randInd = gsl_rng_uniform_int(rng, population.size() );
			randPos = gsl_rng_uniform_int(rng, population[randInd].size() - (length));

			/*Debug
			if (time % printTime == 0 || time <= 2) {
			  cerr << time << "\t" << randInd << "\t" << length << "\t" << randPos << "\t" << type;
			  cerr << "\t" << fitnesses[randInd] << "\t-->\t";
			}
			*/

			indel( population[randInd], randPos, length, type);
			fitnesses[randInd] = computeFitness( population[randInd] );
			n_printed++;

			/*Debug
			if (time % printTime == 0 || time <= 2) {
			  cerr << fitnesses[randInd] << endl;
			}
			*/
		}
	}
}

void EvolSimulator::print(bool forcePrint) const
{
	cout << "time = " << time << endl;
	if (time % printTime != 0 && time != 2 && !forcePrint)
		return;

	if (forcePrint) {
		print(forcePrint, "last_population");
		printAligned(forcePrint, "last_population_aligned");
	}
	printToCout(false);

}

void EvolSimulator::print(bool printAll, string filename) const 
{
	ofstream out(filename.c_str());
	for ( int i = 0; i < population.size(); i++ ) {
		if (printAll || gsl_rng_uniform ( rng ) < printProb) {
			Sequence seq;
			population[i].reconstructSeq(seq);
			out << seq << "\t" << fitnesses[i] << endl;
		}
	}
	out.close();
}


// Prints a sequence that is aligned to the original sequence.
// that means insertions will be ignored and deletions will be replaced
// with gaps.
void EvolSimulator::printAligned(bool printAll, string filename) const 
{
	ofstream out(filename.c_str());
	for ( int i = 0; i < population.size(); i++ ) {
		if (printAll || gsl_rng_uniform ( rng ) < printProb) {
			Sequence seq;
			population[i].reconstructGappedAlignment(seq);
			out << seq << "\t" << fitnesses[i] << endl;
		}
	}
	out.close();
}


void EvolSimulator::printToCout(bool printAll) const
{
	for ( int i = 0; i < population.size(); i++ ) {
		if (printAll || gsl_rng_uniform ( rng ) < printProb) {
			Sequence seq;
			population[i].reconstructSeq(seq);
			cout << seq << "\t" << fitnesses[i] << endl;
		}
	}
}

double EvolSimulator::computeFitness( const SequenceCompact& seq ) const
{

	// the original sequence
	Sequence origSeq;
	seq.reconstructSeq( origSeq );

	// the phenotype
	Phenotype pheno;
	phenoFunc->computePhenotype( origSeq, pheno );

#if 0	
	//Scales the function to get the best result.
	double beta;
	least_square(pheno.exprProfile, fitnessFunc->target.getExprProfile(), beta);
	for (int i = 0; i < pheno.exprProfile.size(); i++){
		pheno.exprProfile[i] *= beta;
		if (pheno.exprProfile[i] > 1)
			pheno.exprProfile[i] = 1;
	}
	//cout << pheno << '\t' << fitnessFunc->computeFitness( pheno );
	//exit(1);

	// the fitness
	return fitnessFunc->computeFitness( pheno );
#endif

	double f = fitnessFunc->computeFitness( pheno );
	if (n_printed < MAXPRINT) {
		cerr << "#$%\t" << f << '\t' << time << '\t' << avgFit <<  "\t"
				<< minFit << "\t" << pheno << "\t%$#\n";
	}
	return f;
}


void EvolSimulator::mutate( SequenceCompact& currSeq, int pos ) const
{
	assert( pos >= 0); assert(pos < currSeq.size() );

	// the original sequence
	Sequence seq; 
	currSeq.reconstructSeq( seq );

	// random mutation
	int currNt = seq[ pos ];
	int mutNt = bgModel->randomMove(rng, currNt);

	//vector< double > probs( 4, 1.0 / 3 );
	//probs[ currNt ] = 0;
	//int mutNt = sampleMul( rng, probs );

	currSeq.addSubstitution(pos, mutNt);
}

void EvolSimulator::indel( SequenceCompact &currSeq, int pos, int length, int type) const {
	
	assert (type == INSERTION || type == DELETION);

	Sequence seq;	
	//generates a random sequence of the given length
	if (type == INSERTION) {
		if (gsl_rng_uniform(rng) < tandem_repeat_probability) {
			// tandem repeat
			Sequence current_sequence;
			currSeq.reconstructSeq(current_sequence);
			int randPos = pos - length - 1;
			if (randPos < 0) {
				randPos = gsl_rng_uniform_int(rng, current_sequence.size() - (length));
			}
			for (int i = 0; i < length; i++) {
				seq.push_back(current_sequence[randPos + i]);
			}
		} else {
			for (int i = 0; i < length; i++) {
				seq.push_back((int) gsl_rng_uniform_int(rng, 4)); 
			}
		}
	}

	currSeq.addIndel(pos, length, seq, type);
	
}

void EvolSimulator::sampleNextGeneration( vector< int >& nextGen ) const
{
	nextGen.clear();

	// create an array of size about 2N that will be a scaled version 
	// of the cumulative distribution of fitness values
	// this is basically the intermediatePop Xin was using,
	// except that instead of being a variable size population obtained by 
	// Poisson sampling, it will be a fixed size population with 
	// representation proportional to the fitnesses
	double sumFitness = 0;
	for ( int i = 0; i < population.size(); i++ ) {
	  sumFitness += (1 + fitnesses[i] * selectionScale * selectionCoeff);
	}
	if (sumFitness <= 0) {
	  cerr << "ERROR: No positive fitness seen" << endl;
	  exit(1);
	}
	
	vector< int > intermediatePop;
	int popsize = population.size();
	for ( int i = 0; i < popsize; i++ ) {
	  int nOffsprings = int(
	  		floor(1000 * popsize * 
	  		(1 + fitnesses[i] * selectionScale * selectionCoeff) / 
			sumFitness + 0.5));

	  for ( int j = 0; j < nOffsprings; j++ ) {
	    intermediatePop.push_back( i );	
	  }
	}
	 
	int interpopsize = intermediatePop.size();
	// cerr << "Intermediate popn of size " << interpopsize << endl;
	for ( int i = 0; i < popsize; i++ ) {
	  int idx = gsl_rng_uniform_int( rng, interpopsize );
	  nextGen.push_back( intermediatePop[idx] );
	}
	
}

void EvolSimulator::SerializePopulation(const string& file_name) const {
	ofstream fout(file_name.c_str());

	// Prints the reference sequence:
	fout << refSeq << endl;
	for (int i = 0; i < population.size(); i++) {\
		fout << population[i].SerializeToString() << endl;
	}

	fout.close();
}

double PopulationSummarizer::getBestSeq( Sequence& bestSeq, Phenotype& bestPheno )
{
	// get the index of the best sequence
	double maxFitness = 0;
	int idxBestSeq = 0;
	for ( int i = 0; i < simulator.population.size(); i++ ) {
		if ( simulator.fitnesses[i] > maxFitness ) {
			maxFitness = simulator.fitnesses[i];
			idxBestSeq = i;
		}
	}

	// return the sequence, phenotype and fitness
	simulator.population[idxBestSeq].reconstructSeq( bestSeq );
	simulator.getPhenoFunc()->computePhenotype( bestSeq, bestPheno );
	return maxFitness;
}

void PopulationSummarizer::sampleSeqs( const gsl_rng* rng, int n, vector< Sequence >& seqs ) const
{
	seqs.clear();

	for ( int i = 0; i < n; i++ ) {
		// sample an index
		int idx = gsl_rng_uniform_int( rng, simulator.population.size() );

		// get the sequence
		Sequence seq;
		simulator.population[idx].reconstructSeq( seq );
		seqs.push_back( seq );
	}
}

void PopulationSummarizer::sampleSeq( const gsl_rng* rng, Sequence& seq ) const
{
	int idx = gsl_rng_uniform_int( rng, simulator.population.size() );
	simulator.population[idx].reconstructSeq( seq );
}
