#ifndef BASE_SEQUENCE_H
#define BASE_SEQUENCE_H
#include <cctype>
#include <cstring>
#include <string>
#include <utility>

#include "Tools.h"
#include "SeqAnnotator.h"

// alphabet
const int MAX_SEQ_LENGTH = 10000;

/* Utility functions */
bool isExtendedSymbol( int a );
// test if a is a nt. or an extended symbol
bool isNtOrExtended( int a );
// test if a -> b is transition or transversion where a, b are nts.
bool isTransition( int a, int b );
// generate the distribution of nts from GC content
vector< double > createDistr( double GC_content );
// map a pair of symbols to alignment state (0, 1 or 2)
int alnState( int x, int y );

/* BaseSequence class */
class BaseSequence {
protected:
	vector< int > nts;		// nts[ i ]: the i-th nt.
public:
	// constructors
	BaseSequence() : nts() {}
	BaseSequence( const vector< int >& _nts );
	virtual void copy( const BaseSequence& other ) { nts = other.nts; }
	BaseSequence( const BaseSequence& other ) { copy( other ); }
	
	// assignment
	BaseSequence& operator=( const BaseSequence& other ) { copy( other ); return *this; }

	// access methods
	int size() const { return nts.size(); }
	int getNt( int pos ) const { 
		assert( pos >= 0 && pos < size() );
		return nts[ pos ]; 
	}
	void setNt( int pos, int nt ) { 
		assert( pos >= 0 && pos < size() && isNtOrExtended( nt ) );
		nts[ pos ] = nt; 
	}
	const int& operator[]( int pos ) const {
		assert( pos >= 0 && pos < size() );
		return nts[ pos ];	
	}
	int& operator[]( int pos ) {
		assert( pos >= 0 && pos < size() );
		return nts[ pos ];	
	}
	const vector< int >& getNts() const { return nts; }
	
	// check if a BaseSequence contains gap
	bool containsGap() const;
	
	// information of the sequence
	void getNtCounts( vector< int >& counts ) const;
	
	// insert a nt. at the end of sequence
	virtual int push_back( int nt );	
	
	// clear the sequence
	void clear() { nts.clear(); }
};

#endif
