#include "SeqAnnotator.h"
#include "Parser.hpp"

using namespace std;

int main(int argc, char *argv[]) {

	//if (argc != 2){
	//	cout << "Usage: " << argv[0] << " config\n";
	//	return 0;
	//}

	Parser parser;
	Dictionary params;
	vector <Motif> motifs;
	vector <Sequence> seqs;
	vector <string> seqNames;
	vector <string> motifNames;
	int rval; 

	rval = parser.parseFile("annotate.config", params);
	assert (rval == 0);
	
	rval = readSequences(params.getStringFor("fa_file"), seqs, seqNames);
	assert (rval == 0);
	//cout << seqs << endl;

	vector <double> background = createNtDistr( params.getDoubleFor("gcContent") );
	
	rval = readMotifs(params.getStringFor("motif_file"), background, motifs, motifNames);
	assert (rval == 0);
	//cout << motifs << endl;

	vector <double> energyThrs(motifs.size(), params.getDoubleFor("energyThr")); 

	bool humanReadble = params.getBoolFor("human_readble");
    int useLR = params.contains("useLR") ? params.getIntFor("useLR") : 0; 

	SeqAnnotator ann(motifs, energyThrs);

	int totalsites = 0;
	for (int i = 0; i < seqs.size(); i++) {
		SiteVec sites;
		ann.annot_LLR_or_LR(seqs[i], sites, useLR);
		
		if (humanReadble) {
			cout << "Sequence " << seqNames[i] << endl;
			cout << "Number of sites: " << sites.size() << endl;
			cout << "Number of sites per factor:";
		}
		else {
			cout << ">" << seqNames[i] << endl;
		}
		
		vector <int> sitesPerFactor(motifs.size(), 0);
		for (int j = 0; j < sites.size(); j++){
			sitesPerFactor[sites[j].factorIdx]++;
			totalsites++;
		}
		if (humanReadble) {
			for (int j = 0; j < motifs.size(); j++){
				cout << "\n\tFactor " << j << ": " << sitesPerFactor[j] << " ";
			}
			cout << endl;
		}
		
		if(humanReadble)
			cout << "Sites found:\n";
		cout << "\t" << sites;
	}

	ofstream total(".total");
	total << totalsites;
	total.close();
	return 1;
}
