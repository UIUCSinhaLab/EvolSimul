#include <ctime>
#include <gsl/gsl_randist.h>
#include <sstream>
#include <fstream>

#include "FitnessSiteSimulator.h"

#define PRINT_EVOLUTIONARY_PATH

FitnessSiteSimulator::FitnessSiteSimulator(const gsl_rng* _rng, 
		double _selectionCoeff, ExprFunc* _exprFunc, 
		const vector< double >& _energyThrs, 
		const Environment& _env, const Phenotype& _evolTarget,
		const SubstModel* _bgModel) : 
				BaseSiteSimulator(_rng), 
				bgModel( _bgModel ), 
				exprFunc( _exprFunc ), energyThrs( _energyThrs ),
				env( _env ), evolTarget( _evolTarget ), time( 0 ),
				selectionCoeff(_selectionCoeff)
{
	assert( rng != NULL ); 

	phenoFunc = new PhenotypeFunc( exprFunc, energyThrs, env );
	fitnessFunc = new FitnessFunc( evolTarget );
}


/*
 * Computes the fitness of a sequence. 
 */
double FitnessSiteSimulator::computeFitness (const Sequence& seq) const {
	Phenotype pheno;
	phenoFunc->computePhenotype( seq, pheno );
	double f = fitnessFunc->computeFitness( pheno );
	return f;
}


/*
 * Evolves an ancient sequence into a descendent sequence.
 */ 
int FitnessSiteSimulator::evolve( const Sequence& ancSeq, int siteStart,
		int siteEnd, double t, Sequence& descSeq, TfbsMotif& motif) const
{

	int motifLength = siteEnd - siteStart;
	int totalLength = ancSeq.size();
	
	// Calculates the inital site energy
	#ifdef PRINT_EVOLUTIONARY_PATH
		SeqElement site = SeqElement(ancSeq, siteStart, motifLength);
		double initial_energy = motif.energy(site);
		ofstream evolutionaryPathFile;
		evolutionaryPathFile.open("evolutionary_path", ios::out | ios::app);
	#endif

	// mutation rate matrix 
	Matrix mutRateMatrix = bgModel->getRateMatrix();
	
	double clock = 0; 
	// rate of each possible mutation at each position
	vector< vector< double > > rates( motifLength ); 
	for ( int i = 0; i < motifLength; i++ ) {
		for ( int j = 0; j < NBASES; j++ ) {
			rates[ i ].push_back( 0 );
		}
	}

	Sequence currentSeq = ancSeq;
	//cerr << "-------------------------------" << endl;
	while ( true ) {

		double currentFitness = computeFitness(currentSeq);
		//cerr << currentFitness << " -> ";

		// prints the current state:
		#ifdef PRINT_EVOLUTIONARY_PATH

			SeqElement site = SeqElement(currentSeq, siteStart, motifLength);
			double energy = motif.energy(site);
			double energy_delta = initial_energy - energy;

			// Checks whether this was included as a site.
			SiteVec sites;
			phenoFunc->ann->annot( currentSeq, sites );
			bool siteFound = false;
			for (int i = 0; i < sites.size(); i++) {
				if (sites[i].start == siteStart && sites[i].factorIdx == 0) {
					siteFound = true;
					break;
				}
			}

			// prints the current sequence, the fitness, the energy
			// delta and the current clock
			evolutionaryPathFile << site << " " << siteFound << "\t" 
			                     << currentFitness << "\t" 
			                     << energy_delta << "\t" << clock << endl;
		#endif

		// compute the rates at each position
		for ( int i = 0; i < motifLength; i++ ) {
			for ( int j = 0; j < NBASES; j++ ) {
				if ( j == currentSeq[siteStart + i] ) {
					rates[ i ][ j ] = 0;
				}
				else {
					Sequence mutSeq = currentSeq; 		

					// mutation rate 
					mutSeq[siteStart + i] = j;
					double mutRate = mutRateMatrix(currentSeq[siteStart + i],
												   mutSeq[siteStart + i]);
					
					// fitness of the mutated site
					double mutedFitness = computeFitness(mutSeq); 
					//cerr << mutedFitness << " ";
					
					// rate of substitution, depending on the fitness difference
					double fitDiff = mutedFitness - currentFitness; 
					fitDiff = fitDiff * 4 * selectionCoeff;
					double accProb; 
					if ( fitDiff > 0 ) {
						accProb = fitDiff / ( 1.0 - exp( -fitDiff ) ); 
					} else if ( fitDiff < 0 ) {
						accProb = (-fitDiff) / ( exp( -fitDiff ) - 1 );	
					} else {
						accProb = 1;
					}	
					rates[ i ][ j ] = mutRate * accProb; 
				}	
			}
		}
		//cerr << endl;
		
		// total rates at each position 
		double totalRate = 0; 
		vector< double > posRates(motifLength); 
		for ( int i = 0; i < motifLength; i++ ) {
			double rate = 0; 
			for ( int j = 0; j < NBASES; j++ ) {
				rate += rates[ i ][ j ];
			}
			posRates[ i ] = rate;
			totalRate += posRates[ i ]; 
		}
				
		// sample the mutational event 
		int pos; 	// position of the event 
		int base; 	// base of the event
		double timeNext = gsl_ran_exponential( rng, 1.0 / totalRate );
		clock += timeNext; 
		if ( clock > t ) break; 

		// sample a position
		vector< double > posProbs( motifLength ); 
		for ( int i = 0; i < motifLength; i++ ) {
			posProbs[ i ] = posRates[ i ] / totalRate; 
		}
		pos = sampleMul( rng, posProbs );

		// sample a nucleotide to mutate to
		vector< double > ntProbs( NBASES ); 
		for ( int j = 0; j < NBASES; j++ ) {
			ntProbs[ j ] = rates[ pos ][ j ] / posRates[ pos ];	
		}
		base = sampleMul( rng, ntProbs );
		
		// update the site
		currentSeq[siteStart + pos] = base;

	}
	
	descSeq = currentSeq; 
}

string FitnessSiteSimulator::simulate(
		int N,
		double simulTime,
		Sequence& ancSeq,
		int siteStart, 
		int siteEnd,
		TfbsMotif& motif,
		double* ancientEnergy, 
		double* descendentEnergy,
		double* ancientFitness,
		double* descendentFitness)
{
	assert( N > 0 && simulTime > 0 );
	int motifLength = siteEnd - siteStart;
	simulatedPairs.clear();
	
	Sequence descSeq;
	double ancEnergy, descEnergy;
	ostringstream ss;
	for ( int i = 0; i < N; i++ ) {
		SeqElement site = SeqElement(ancSeq, siteStart, motifLength);
		ancEnergy = motif.energy( site );
		
		// evolve the site
		evolve(ancSeq, siteStart, siteEnd, simulTime, descSeq, motif); 
		SeqElement descSite = SeqElement(descSeq, siteStart, motifLength);
		descEnergy = motif.energy( descSite );

		*ancientEnergy = ancEnergy;
		*descendentEnergy = descEnergy;

		// Calculates the fitness of the sequences
		*ancientFitness = computeFitness(ancSeq); 
		*descendentFitness = computeFitness(descSeq); 

		if ( 1 ) cout << "AncSite = " << site << "\tAncEnergy = " 
		              << ancEnergy << "\tDescSite = " << descSite 
					  << "\tDescEnergy = " << descEnergy << endl;
		
		// insert the energy of the pairs
		simulatedPairs.push_back( make_pair( ancEnergy, descEnergy ) );
		ss << descSite;
	}

	//cerr << ancSeq << "\t" << ancEnergy << endl << descSeq << "\t" << descEnergy << endl;
		
	return ss.str();	
}
