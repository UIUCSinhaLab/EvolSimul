#include "RandomWalk.h"


RandomWalk::RandomWalk (const gsl_rng* _rng, ExprFunc* _exprFunc, const vector< double >& _energyThrs, const Environment& _env, const Phenotype& _evolTarget ) : rng( _rng ), exprFunc( _exprFunc ), energyThrs( _energyThrs ), env( _env ), evolTarget( _evolTarget ), time( 0 ), substitution_probability(1), insertion_probability(0), expectedIndelLength(1)

{

  assert (_rng != NULL);
	
  phenoFunc = new PhenotypeFunc( exprFunc, energyThrs, env );
  fitnessFunc = new FitnessFunc( evolTarget );

}


void RandomWalk::setIndelParameters(double _substitution_probability, double _insertion_probability, double _expectedIndelLength) {
	
  substitution_probability = _substitution_probability;
  insertion_probability = _insertion_probability;
  expectedIndelLength = _expectedIndelLength;

}

void RandomWalk::initialize (const Sequence &initSeq) 
{

  refSeq = initSeq;
  time = 0;

  SequenceCompact seq( initSeq );
  population.clear();
  population.push_back( seq );
  fitness = computeFitness( );
  print();
  // cerr << "1\tinitial\t-\t-\t-\t-\t-->\t";
  // cerr << fitness << endl;

}


int RandomWalk::insertionLength(){
  if (gsl_rng_uniform(rng) < 0.56374)
    return gsl_ran_geometric(rng, 0.23986);
  else
    return gsl_ran_geometric(rng, 0.082786);
}

int RandomWalk::deletionLength(){
  if (gsl_rng_uniform(rng) < 0.38518)
    return gsl_ran_geometric(rng, 0.38433);
  else
    return gsl_ran_geometric(rng, 0.10117);

}


void RandomWalk::walk (int nGenerations) 
{

  for (int t=0; t < nGenerations; t++) {
    time++;
    doMutations(); // this will modify the SequenceCompact object "population" and update the fitness value
    print();
  }
}

void RandomWalk::doMutations()
{

  int randInd, randPos;
	
  int type;
  //Chooses the mutation type: Substitution or indel.
  if (gsl_rng_uniform( rng ) < substitution_probability) { 
	  
    // A substitution
	  
    randPos = gsl_rng_uniform_int( rng, population[0].size() );    
    
    mutate( randPos );
    fitness = computeFitness();
  }
  else 
    {
      int length;
      if (gsl_rng_uniform(rng) < insertion_probability) {
	//An insertion
	type = INSERTION;
	length = insertionLength();
      }
      else {
	//A deletion
	type = DELETION;
	length = deletionLength();
      }
	    
      randPos = gsl_rng_uniform_int (rng, population[0].size() - (length));
	    
      indel( randPos, length, type);
      fitness = computeFitness();
    }
}

void RandomWalk::print(bool forcePrint) const
{
  if (time % EvolSimulator::printTime != 0 && time != 2 && !forcePrint)
    return;
  Sequence seq;
  population[0].reconstructSeq( seq );
  cout << time << "\t" << seq << "\t" << fitness << endl;

}	

double RandomWalk::computeFitness( ) const
{

  // the original sequence
  Sequence origSeq;
  population[0].reconstructSeq( origSeq );
  Phenotype pheno;
  phenoFunc->computePhenotype( origSeq, pheno );

  double f = fitnessFunc->computeFitness( pheno );
  // if (time % EvolSimulator::printTime == 0 || time <= 2) {
  //  cerr << f << '\t' << pheno << '\t';
  // }
  return f;

}

void RandomWalk::mutate(int pos) 
{
 
  // the original sequence
  Sequence seq; 
  population[0].reconstructSeq( seq );

  // random mutation
  int currNt = seq[ pos ];
  vector< double > probs( 4, 1.0 / 3 );
  probs[ currNt ] = 0;
  int mutNt = sampleMul( rng, probs );

  population[0].addSubstitution(pos, mutNt);
}

void RandomWalk::indel(int pos, int length, int type)
{
  
  assert (type == INSERTION || type == DELETION);
  
  Sequence seq;	
  //generates a random sequence of the given length
  for (int i = 0; i < length; i++) {
    seq.push_back((int) gsl_rng_uniform_int(rng, 4)); 
  }
  
  population[0].addIndel(pos, length, seq, type);
	
}

