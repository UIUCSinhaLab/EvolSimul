#include <stdio.h>
#include "EvolSimulator.h"

class RandomWalk {

	public:

		RandomWalk ( const gsl_rng* _rng, ExprFunc* _exprFunc, const vector< double >& _energyThrs, 
                                const Environment& _env, const Phenotype& _evolTarget );

		// access methods
		int getTime() const {
			return time;
		}
		const PhenotypeFunc* getPhenoFunc() const {
			return phenoFunc;
		}
		const FitnessFunc* getFitnessFunc() const {
			return fitnessFunc;
		}

		// initialize the population with a sequence 
		void initialize( const Sequence& initSeq );
		void setIndelParameters(double substitution_probability, double insertion_probability, double expectedIndelLength);

		// evolve the population for a certain number of generations
		void walk ( int nGenerations );

		// print the population (for debugging purpose)
		void print(bool forcePrint = false) const;
		

	private:

		const gsl_rng* rng;

		double substitution_probability;
		double insertion_probability;
		double expectedIndelLength;
		
		ExprFunc* exprFunc;              // the ExprFunc object, containing the relevant parameters
		vector< double > energyThrs;     // the energy thresholds for all motifs
		Environment env;                 // the current environment
		Phenotype evolTarget;            // the evolutionary target
		
		int time;
		Sequence refSeq;	// the reference sequence
		vector<SequenceCompact> population; // dont really need a vector, but SequenceCompact constructor missing.
		double fitness;

		PhenotypeFunc *phenoFunc;
		FitnessFunc *fitnessFunc;

		double computeFitness( ) const;

		// mutation of one sequence (random substitution)
		void doMutations();
		void mutate( int pos );
		void indel( int pos, int len, int type);
		int insertionLength();
		int deletionLength();

};
