#include "FitnessSampler.h"
#include <algorithm>

SequenceSampler::SequenceSampler( const gsl_rng* _rng, const vector< Motif >& _motifs, 
								  const vector< double >& _bgFreqs, const vector<double>& _energyThrs,
								  int _useLR) : rng( _rng ), motifs( _motifs ), bgFreqs( _bgFreqs ), 
								  energyThrs(_energyThrs), useLR(_useLR)
{
     assert( isPmf( bgFreqs ) );
	 allBidingSites.clear();
	 prepareForSample();
}

bool SequenceSampler::isConfigLeg( const vector< int >& config, int L ) const
{
    assert( config.size() == motifs.size() && L > 0 ); 

    // the total length of all sites 
    int sitesTotLen = 0; 
    for ( int i = 0; i < config.size(); i++ ) {
        sitesTotLen += config[i] * motifs[i].length();
    }

    if ((double)sitesTotLen / L > maxSiteRatio ) return false;
    else return true; 
}

void SequenceSampler::prepareForSample () {
	for (int motif = 0; motif < motifs.size(); motif++) {
		vector<Sequence> bidingSites;
		Sequence seq;
		ennumerateAllBindingSites(motif, seq, bidingSites);
		allBidingSites.push_back(bidingSites);
	}
}

void SequenceSampler::ennumerateAllBindingSites(int motif, Sequence &seq, vector<Sequence> &bidingSites ) {
	if (seq.size() == motifs[motif].length()) {
		SeqAnnotator annotator( motifs, energyThrs );
		SiteVec sites; 
		annotator.annot_LLR_or_LR( seq, sites, useLR ); 
		for (int i = 0; i < sites.size(); i++) {
			if (sites[i].factorIdx == motif) {
				bidingSites.push_back(seq);
			}
		}
	}
	else {
		for (int i = 0; i < 4; i++) {
			Sequence tmp = Sequence(seq); //Copies seq to a tmp sequence
			tmp.push_back(i);             //Add a nucleotide to the end of the sequence
			ennumerateAllBindingSites(motif, tmp, bidingSites);
		}
	}
}

void SequenceSampler::sampleSite(int motif, Sequence& seq) const
{
	int rnd_site = gsl_rng_uniform_int(rng, allBidingSites[motif].size());
	seq = allBidingSites[motif][rnd_site];
}

int SequenceSampler::sample( const vector< int >& config, int L, Sequence& seq ) const
{
    assert( config.size() == motifs.size() && L > 0 );
    
    seq.clear();
    for ( int i = 0; i < L; i++ ) seq.push_back( 0 );
    
    // the sites to be sampled (which motif a site comes from)
    vector< int > allSites;
    for ( int i = 0; i < motifs.size(); i++ ) {
        allSites.insert( allSites.end(), config[i], i ); 
    }
    random_shuffle( allSites.begin(), allSites.end() );

    // sample sites
    vector< int > occ( L, 0 );  // occupancy status of L cells: 1 if occupied, 0 if free
    for ( int i = 0; i < allSites.size(); i++ ) {
        int k = allSites[i];    // motif index
        int l = motifs[k].length();
        int start = -1;

        // find a free block of size l (motif length)
        for ( int i = 0; i < ntrials; i++ ) {    
            // find the first available block
            int rand_start = gsl_rng_uniform_int( rng, L );
            for ( int j = rand_start; j <= L - l; j++ ) {
                if ( isBlockFree( occ, j, l ) ) {
                    start = j; 
                    break; 
                }
            }

            // sample and plant the site
            if ( start != -1 ) {
                Sequence elem;
				sampleSite (k, elem);
                for ( int j = 0; j < elem.size(); j++ ) {
                    seq[start + j] = elem[j]; 
                }
                markBlock( occ, start, l, 1 );
                break; 
            }
        }

        if ( start == -1 ) {
            cerr << "Cannot sample the sequence with configuration " << config << endl;
            exit( 1 ); 
        }
    }
    
    // sample the background sequence
    for ( int i = 0; i < L; i++ ) {
        if ( !occ[i] ) seq[i] = sampleMul( rng, bgFreqs ); 
    }

    return 0;
}

double SequenceSampler::maxSiteRatio = 0.5; 

int SequenceSampler::ntrials = 10; 

bool SequenceSampler::isBlockFree( const vector< int >& occ, int pos, int l ) const
{
    if ( pos + l > occ.size() ) return false; 
    
    for ( int i = 0; i < l; i++ ) {
        if ( occ[pos + i] == 1 ) return false; 
    }

    return true; 
}

int SequenceSampler::markBlock( vector< int >& occ, int pos, int l, int status ) const
{
    for ( int i = 0; i < l; i++ ) {
        occ[pos + i] = status;
    }

    return 0;
}

FitnessSummarizer::FitnessSummarizer( const vector< Motif >& _motifs, const vector< double >& _energyThrs, 
		const vector< int >& _maxNumSites, const PhenotypeFunc* _phenoFunc, 
		const FitnessFunc* _fitnessFunc, double _minFit, int _useLR ) : motifs( _motifs ), energyThrs( _energyThrs ), 
		maxNumSites( _maxNumSites ), phenoFunc( _phenoFunc ), fitnessFunc( _fitnessFunc ), minFit( _minFit ),
		useLR (_useLR)
{
    int nmotifs = motifs.size();
    assert( energyThrs.size() == nmotifs && maxNumSites.size() == nmotifs ); 
}

double FitnessSummarizer::compFitness( const Sequence& seq ) const
{
    Phenotype pheno; 
    phenoFunc->computePhenotype( seq, pheno ); 
    return fitnessFunc->computeFitness( pheno ); 
}

int FitnessSummarizer::computeFitnessSummary( const vector< Sequence >& seqs, vector< FitnessInfo >& fitnessSummary ) const
{
    int nmotifs = motifs.size();

    // initialization: the vector V is used for mapping 1-D representation of configurations with its K-D representation
    vector< int > V( nmotifs );
    V[0] = 1 + maxNumSites[0]; 
    for ( int i = 1; i < nmotifs; i++ ) {
        V[i] = V[i-1] * ( 1 + maxNumSites[i] );
    }
    vector< vector< double > > fitnessVals( V[nmotifs - 1] );
    
    // compute and store fitness of any sequence, according to the configuration
    for ( int i = 0; i < seqs.size(); i++ ) {
        // configuration
        vector< int > config;   
        countSites( seqs[i], config ); 
        if ( outOfBound( config ) ) continue;
        int idx = rev_index_map( config, V );

        // fitness 
        double fit = compFitness( seqs[i] ); 
		if (fit > minFit) { 
			cout << config << "\t" << fit << "\t" << seqs[i] << endl;
		}
		fitnessVals[idx].push_back( fit );
    }

    // generate the summary
    for ( int i = 0; i < fitnessVals.size(); i++ ) {
		
		for (int j = 0; j < fitnessVals[i].size(); j++) {
			//cerr << i << " - " << fitnessVals[i][j] << endl;
		}
        if ( fitnessVals[i].size() ) {
            double avg = mean( fitnessVals[i] ); 
            double sd = ( fitnessVals[i].size() > 1 ) ? std_dev( fitnessVals[i] ) : nullFitnessVal;
			double GEMinFit = 0;
			for (int j = 0; j < fitnessVals[i].size(); j++) {
				GEMinFit += (fitnessVals[i][j] >= minFit) ? 1 : 0;
				
			}
			GEMinFit /= fitnessVals[i].size();
            fitnessSummary.push_back( 
					FitnessInfo( avg, sd , GEMinFit, fitnessVals[i].size()));
		}
    }
    
    return 0;
}

double FitnessSummarizer::nullFitnessVal = -1.0; 

int FitnessSummarizer::countSites( const Sequence& seq, vector< int >& nsites ) const
{
    SeqAnnotator annotator( motifs, energyThrs );
    SiteVec sites; 
    annotator.annot_LLR_or_LR( seq, sites, useLR ); 

    // initialize
    nsites.clear();
    for ( int i = 0; i < motifs.size(); i++ ) nsites.push_back( 0 );

    // count sites
    for ( int i = 0; i < sites.size(); i++ ) {
        nsites[ sites[i].factorIdx ]++;
    }

    return  0;
}

bool FitnessSummarizer::outOfBound( const vector< int >& config ) const
{
    assert( config.size() == motifs.size() );
    
    for ( int i = 0; i < config.size(); i++ ) {
        if ( config[i] > maxNumSites[i] ) return true;
    }

    return false; 
}
