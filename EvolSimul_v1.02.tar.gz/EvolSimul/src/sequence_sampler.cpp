/*
 * Samples a sequence with an specific configuration of binding sites.
 * Can also calculate the fitness and phenotype of that sequence.
 */
#include "FitnessSampler.h"
#include "Parser.hpp"

int main( int argc, char* argv[] )
{
	// command line processing
    if (argc != 2){
	  cerr << "Usage: "<< argv[0] << " <param_file>" << endl;
	  exit(1);
	}

    Parser parser;
	Dictionary params;
	int rval = parser.parseFile(argv[1], params);
	
	//Input files
    ModelType modelOption = getModelOption(params.getStringFor("modelOption"));
	string motifFile = params.getStringFor("motifFile");
	string factorExprFile = params.getStringFor("factorExprFile");
	string factorInfoFile = params.getStringFor("factorInfoFile");
    string targetExprFile = params.getStringFor("targetExprFile");
	string coopFile = params.contains( "cooperationFile" ) ? 
			params.getStringFor("cooperationFile") : "";
	string repressionFile = params.contains( "repressionFile" ) ? 
			params.getStringFor("repressionFile") : "";

	// A file with all configurations we want to generate
	string siteCountsFile = params.getStringFor("siteCountsFile");
	
	// additional control parameters of the expression model
	double gcContent = params.contains("gcContent") ? 
			params.getDoubleFor("gcContent") : 0.5;
	double energyThr = params.contains("energyThr") ? 
			params.getDoubleFor("energyThr") : 4.0; 
	double coopDistThr = params.contains("coopDistThr") ? 
			params.getDoubleFor("coopDistThr") : 100;
    double repressionDistThr = params.contains("repressionDistThr") ? 
			params.getDoubleFor("repressionDistThr") : 100;

	int maxContact = params.contains("maxContact") ? params.getIntFor("maxContact") : 1;
	double basalTxp = params.contains("basalTxp") ? params.getDoubleFor("basalTxp") : 0.001;

	//Fitness function parameters
	FitnessFunc::D_max = params.getDoubleFor("D_max");   
	FitnessFunc::selectionExp = params.getDoubleFor("selectionExp");

    // parameters of the fitness mapping function 
    int nseqsPerConfig = params.getIntFor("nseqsPerConfig");
    int seqLength = params.getIntFor("seqLength");
    int maxNumSitesPerMotif = params.getIntFor("maxNumSitesPerMotif");  
    double energyThrFitness = params.contains("energyThrFitness") ? 
			params.getDoubleFor("energyThrFitness") : 3.0; 
    int useLR = params.contains("useLR") ? params.getIntFor("useLR") : 0; 
    double minFit = params.contains("minFit") ? params.getDoubleFor("minFit"): 0.0;

	// Reporting parameters:
	bool printFitnessSummary = params.contains("printSummary") ?
			params.getBoolFor("printSummary") : false;

    if ( motifFile.empty() || factorExprFile.empty() || factorInfoFile.empty() || 
		 ( modelOption == QUENCHING && repressionFile.empty() ) || targetExprFile.empty() ) {
		cerr << "Incorrect parameter file.\n";
		exit( 1 );
	}
    
    string factor1, factor2;    // buffer for reading factor pairs
    
    // read the motifs
    vector< Motif > motifs;
    vector< string > motifNames;
    vector< double > background = createNtDistr( gcContent );
    rval = readMotifs( motifFile, background, motifs, motifNames ); 
    assert( rval != RET_ERROR );
    int nFactors = motifs.size();

    // factor name to index mapping
    map< string, int > factorIdxMap;
    for ( int i = 0; i < motifNames.size(); i++ ) {
        factorIdxMap[motifNames[i]] = i;
    }
 
    // read TF information: binding, activation and repression
    ifstream finfo( factorInfoFile.c_str() );
    if ( !finfo ) {
        cerr << "Cannot open the factor information file " << factorInfoFile << endl;
        exit( 1 );
    }
    vector< double > maxBindingWts( nFactors );
    vector< double > txpEffects( nFactors );
    vector< double > repEffects( nFactors );
    string name;
    double effect;
    int i = 0;
    while ( finfo >> name >> maxBindingWts[i] >> effect >> repEffects[i] ) {
        assert( name == motifNames[i] );
        if ( modelOption == LOGISTIC ) txpEffects[i] = exp( effect );
        else txpEffects[i] = effect;
        i++;
    }
    vector< bool > actIndicators( nFactors, false );
    vector< bool > repIndicators( nFactors, false );
    for ( int i = 0; i < nFactors; i++ ) {
        if ( txpEffects[i] > 1.0 ) actIndicators[i] = true;
        if ( repEffects[i] > 0.0 ) repIndicators[i] = true; 
    }

    // read the cooperativity matrix    
    Matrix factorIntMat( nFactors, nFactors, 1.0 );
    if ( !coopFile.empty() ) {
        ifstream fcoop( coopFile.c_str() );
        if ( !fcoop ) {
            cerr << "Cannot open the cooperativity file " << coopFile << endl;
            exit( 1 );
        }  
        double coopVal;
        while ( fcoop >> factor1 >> factor2 >> coopVal ) {
            assert( factorIdxMap.count( factor1 ) && factorIdxMap.count( factor2 ) );
            int idx1 = factorIdxMap[factor1];
            int idx2 = factorIdxMap[factor2];
            factorIntMat( idx1, idx2 ) = coopVal;
        }        
    }         

    // read the repression matrix 
    IntMatrix repressionMat( nFactors, nFactors, false );
    if ( !repressionFile.empty() ) {
        ifstream frepr( repressionFile.c_str() );
        if ( !frepr ) {
            cerr << "Cannot open the repression file " << repressionFile << endl;
            exit( 1 );
        }        
        while ( frepr >> factor1 >> factor2 ) {
            assert( factorIdxMap.count( factor1 ) && factorIdxMap.count( factor2 ) );
            int idx1 = factorIdxMap[factor1];
            int idx2 = factorIdxMap[factor2];
            repressionMat( idx1, idx2 ) = true;
        }        
    }    
    
    // create the ExprFunc object
    ExprPar::modelOption = modelOption;
    ExprFunc::modelOption = modelOption;
    FactorIntFunc* intFunc = new FactorIntFuncBinary( coopDistThr );
    ExprPar par( maxBindingWts, factorIntMat, txpEffects, repEffects, basalTxp );
    ExprFunc* func = new ExprFunc( motifs, 
								   intFunc, 
								   actIndicators, 
								   maxContact, 
								   repIndicators,
								   repressionMat, 
								   repressionDistThr, 
								   par );

    // read TF expression
    vector< vector< double > > data;    
    vector< string > labels;    
    vector< string > condNames;  
    rval = readMatrix( factorExprFile, labels, condNames, data );   // both row and column labels
    assert( rval != RET_ERROR );
    assert( labels.size() == nFactors );
    for ( int i = 0; i < nFactors; i++ ) assert( labels[i] == motifNames[i] );
    Matrix factorExprData( data ); 
    int nConds = factorExprData.nCols();
    
    // create the Environment
    Environment env( factorExprData );

    // read the evolutionary target
    data.clear();
    labels.clear();
    rval = readMatrix( targetExprFile, labels, data );    // column label only
    assert( rval != RET_ERROR );
    Matrix targetExprData( data ); 
    assert( targetExprData.nRows() == 1 );
    Phenotype targetPheno( targetExprData.getRow( 0 ) );
    
    // random number generator
    gsl_rng_env_setup();
    const gsl_rng_type * T = gsl_rng_default;	// create rng type
    gsl_rng* rng = gsl_rng_alloc( T );
    gsl_rng_set( rng, time( 0 ) );		// set the seed equal to simulTime(0)    
   
	// Creates a vector from the threshold
	vector< double > energyThrsFitness( motifs.size(), energyThrFitness ); 
    	
	// sequence sampler
    vector< double > bgFreq = createNtDistr( gcContent );  
    SequenceSampler sampler( rng, motifs, bgFreq, energyThrsFitness, useLR); 
	
	// Creates a phenotype function and fitness function
	PhenotypeFunc* phenoFunc = new PhenotypeFunc( func, 
												  vector< double >( motifs.size(), energyThr ), 
												  env );
	FitnessFunc* fitFunc = new FitnessFunc( targetPheno ); 
	SeqAnnotator annotator( motifs, energyThrsFitness );
	IO_Ctrl::vector_delimiter = ","; 
	
    
    // sample sequences with the desired configuration
    vector< int > maxNumSites( motifs.size(), maxNumSitesPerMotif ); 
    vector< int > dim_sizes( motifs.size() );
    for ( int i = 0; i < dim_sizes.size(); i++ ) {
        dim_sizes[i] = maxNumSites[i] + 1;
    }
   
	// Creates a fitness summarizer:
	FitnessSummarizer summarizer( motifs, 
	                              energyThrsFitness, 
								  maxNumSites, 
								  phenoFunc, 
								  fitFunc, 
								  minFit, 
								  useLR); 
	vector< FitnessInfo > summary; 
	vector < Sequence > seqs;

	seqs.clear();

	// Reads each configuration from the file and checks the "landscape for that
	// configuration.
	while(!configsFile.eof()) {
		
		vector<int> config;
		// Read the configuration
		for (int i = 0; i < nFactors; i++) {
			if (configsFile.eof()) {
				printf("Error! Invalid configuration\n");
				exit(1);
			}
			int nSites;
			configsFile >> nSites;
			


		for ( int j = 0; j < nseqsPerConfig; j++ ) {
			Sequence seq; 
			sampler.sample( config, seqLength, seq );
			
			//if a sequence happens to have more sites than it should, regenerate
			SiteVec sites; 
			annotator.annot_LLR_or_LR( seq, sites, useLR ); 
			if (i != sites.size()) { 
				j--;
			}
			//Otherwise save the sequence
			else {
				seqs.push_back( seq ); 
			}
		}
		// TODO (generate summaries)
		//summarizer.computeFitnessSummary( seqs, summary ); 

		// TODO print the generated sequences

	}

	// print the fitness summary
	if ( printFitnessSummary) {
		for ( int j = 0; j < summary.size(); j++ ) {
			vector< int > config; 
			cout << "(" << config << ")\t" << summary[j].mean << "\t" 
				<< summary[j].sd << "\t" << summary[j].GEMinFit  << "\t" 
				<< summary[j].n <<  endl;
		}
	}

	return 0;	
}
