#include "EvolSimulator.h"

int main( int argc, char* argv[] )
{
    // command line processing
    string motifFile, factorExprFile, factorInfoFile, coopFile, repressionFile, seqFile, exprFile;
    ModelType modelOption = LOGISTIC; 
    for ( int i = 1; i < argc; i++ ) {
        if ( !strcmp( "-s", argv[ i ] ) )
            seqFile = argv[ ++i ];
        else if ( !strcmp( "-e", argv[ i ] ) )
            exprFile = argv[ ++i ];     
        else if ( !strcmp( "-m", argv[ i ] ) )
            motifFile = argv[ ++i ];
        else if ( !strcmp( "-f", argv[ i ] ) )
            factorExprFile = argv[ ++i ];   
        else if ( !strcmp( "-i", argv[ i ] ) )
            factorInfoFile = argv[ ++i ];  
        else if ( !strcmp( "-o", argv[ i ] ) )
            modelOption = getModelOption( argv[++i] );            
        else if ( !strcmp( "-c", argv[ i ] ) )
            coopFile = argv[ ++i ];            
        else if ( !strcmp( "-r", argv[ i ] ) )
            repressionFile = argv[ ++i ];           
    }	
    if ( motifFile.empty() || factorExprFile.empty() || factorInfoFile.empty() || ( modelOption == QUENCHING && repressionFile.empty() ) || seqFile.empty() || exprFile.empty() ) {
        cerr << "Usage: " << argv[ 0 ] << " -m motifFile -f factorExprFile -i factorInfoFile [-o modelOption -c coopFile -r repressionFile] -s seqFile -e exprFile" << endl;
        exit( 1 );
    }

    int rval;
    string factor1, factor2;    // buffer for reading factor pairs
   
    // additional control parameters of the expression model
    double gcContent = 0.4;
    double energyThr = 4.0;
    double coopDistThr = 150;
    double repressionDistThr = 100; 
    int maxContact = 2;
    double basalTxp = 1.0E-3;
    int seqLength = 663;        // eve stripe 2
    
    // evolutionary parameters
    int N = 100;   // population size
    double mu = 1.0E-8; // mutaiton rate
    FitnessFunc::D_max = 1.0;   
    FitnessFunc::selectionPar = 1.0;
//     int L = 1000;    // sequence length
//     Sequence consensusSeq( string("TAATCCGG" ) );  // consensus sequence
//     double s = 0.1;    // selection coefficient
//     Phenotype P_target( 1 );     // target phenotype
//     Environment env;  // environment

//     Sequence seq( string("TAATCCGA") );
//     cout << compDistance( consensusSeq, seq ) << endl;
//     cout << seq[0] << endl;

    // read the motifs
    vector< Motif > motifs;
    vector< string > motifNames;
    vector< double > background = createNtDistr( gcContent );
    rval = readMotifs( motifFile, background, motifs, motifNames ); 
    assert( rval != RET_ERROR );
    int nFactors = motifs.size();

    // factor name to index mapping
    map< string, int > factorIdxMap;
    for ( int i = 0; i < motifNames.size(); i++ ) {
        factorIdxMap[motifNames[i]] = i;
    }

    // read TF information: binding, activation and repression
    ifstream finfo( factorInfoFile.c_str() );
    if ( !finfo ) {
        cerr << "Cannot open the factor information file " << factorInfoFile << endl;
        exit( 1 );
    }
    vector< double > maxBindingWts( nFactors );
    vector< double > txpEffects( nFactors );
    vector< double > repEffects( nFactors );
    string name;
    double effect;
    int i = 0;
    while ( finfo >> name >> maxBindingWts[i] >> effect >> repEffects[i] ) {
        assert( name == motifNames[i] );
        if ( modelOption == LOGISTIC ) txpEffects[i] = exp( effect );
        else txpEffects[i] = effect;
        i++;
    }
    vector< bool > actIndicators( nFactors, false );
    vector< bool > repIndicators( nFactors, false );
    for ( int i = 0; i < nFactors; i++ ) {
        if ( txpEffects[i] > 1.0 ) actIndicators[i] = true;
        if ( repEffects[i] > 0.0 ) repIndicators[i] = true; 
    }

    // read the cooperativity matrix    
    Matrix factorIntMat( nFactors, nFactors, 1.0 );
    if ( !coopFile.empty() ) {
        ifstream fcoop( coopFile.c_str() );
        if ( !fcoop ) {
            cerr << "Cannot open the cooperativity file " << coopFile << endl;
            exit( 1 );
        }  
        double coopVal;
        while ( fcoop >> factor1 >> factor2 >> coopVal ) {
            assert( factorIdxMap.count( factor1 ) && factorIdxMap.count( factor2 ) );
            int idx1 = factorIdxMap[factor1];
            int idx2 = factorIdxMap[factor2];
            factorIntMat( idx1, idx2 ) = coopVal;
        }        
    }         

    // read the repression matrix 
    IntMatrix repressionMat( nFactors, nFactors, false );
    if ( !repressionFile.empty() ) {
        ifstream frepr( repressionFile.c_str() );
        if ( !frepr ) {
            cerr << "Cannot open the repression file " << repressionFile << endl;
            exit( 1 );
        }        
        while ( frepr >> factor1 >> factor2 ) {
            assert( factorIdxMap.count( factor1 ) && factorIdxMap.count( factor2 ) );
            int idx1 = factorIdxMap[factor1];
            int idx2 = factorIdxMap[factor2];
            repressionMat( idx1, idx2 ) = true;
        }        
    }    
    
    // create the ExprFunc object
    ExprPar::modelOption = modelOption;
    ExprFunc::modelOption = modelOption;
    FactorIntFunc* intFunc = new FactorIntFuncBinary( coopDistThr );
    ExprPar par( maxBindingWts, factorIntMat, txpEffects, repEffects, basalTxp );
    ExprFunc* func = new ExprFunc( motifs, intFunc, actIndicators, maxContact, repIndicators, repressionMat, repressionDistThr, par );

    // read TF expression
    vector< vector< double > > data;
    vector< string > labels;
    vector< string > condNames;  
    rval = readMatrix( factorExprFile, labels, condNames, data );
    assert( rval != RET_ERROR );
    assert( labels.size() == nFactors );
    for ( int i = 0; i < nFactors; i++ ) assert( labels[i] == motifNames[i] );
    Matrix factorExprData( data ); 
    int nConds = factorExprData.nCols();
    
    // create the Environment
    Environment env( factorExprData );

    // read the evolutionary target
    data.clear();
    labels.clear();
    rval = readMatrix( exprFile, labels, data );
    assert( rval != RET_ERROR );
//     assert( labels.size() == nSeqs );
//     for ( int i = 0; i < nSeqs; i++ ) assert( labels[i] == seqNames[i] );
    Matrix exprData( data ); 
//     cout << exprData.nRows() << "\t" << exprData.nCols() << endl;
    assert( exprData.nRows() == 1 );
    Phenotype P_target( exprData.getRow( 0 ) );
    
    // random number generator
    gsl_rng_env_setup();
    const gsl_rng_type * T = gsl_rng_default;	// create rng type
    gsl_rng* rng = gsl_rng_alloc( T );
    gsl_rng_set( rng, time( 0 ) );		// set the seed equal to simulTime(0)    
    
    // create the simulator
    vector< double > energyThrs( nFactors, energyThr );
    EvolSimulator simulator( rng, mu, func, energyThrs, env, P_target );
    
    // initialize the population
    vector< Sequence > seqs;
    vector< string > seqNames;
    rval = readSequences( seqFile, seqs, seqNames );
    assert( rval != RET_ERROR );
    assert( seqs.size() == 1 );
    Sequence initSeq = seqs[0];
    simulator.initialize( N, initSeq );
//     cout << "Initial population:" << endl;
//     simulator.print();

    // TESTING: the running time 
//     int totalTime = 10;
//     simulator.evolve( totalTime );
//     simulator.print();
    
    // evolve the population and report the results
    int cycleLength = 3;
    PopulationSummarizer popSum( simulator );
    Sequence bestSeq;
    Phenotype bestPheno;
    simulator.evolve( cycleLength );
//     do {
//         simulator.evolve( cycleLength );
//         
//         popSum.getBestSeq( bestSeq, bestPheno );
//     } while ( bestPheno.getExprState() < P_target.getExprState() );
//     cout << "Time = " << simulator.getTime() << endl;
//     cout << "Sequence = " << bestSeq << endl;
    
    return 0;
}


