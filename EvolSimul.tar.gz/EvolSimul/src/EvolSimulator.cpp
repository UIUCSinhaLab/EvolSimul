#include <queue>
#include <gsl/gsl_randist.h>
#include "EvolSimulator.h"

int compDistance( const Sequence& seq1, const Sequence& seq2 )
{
    assert( seq1.size() == seq2.size() ); 

    int dist = 0;
    for ( int i = 0; i < seq1.size(); i++ ) {
        if ( seq1[i] != seq2[i] ) dist++;
    }
    
    return dist;
}

SequenceCompact::SequenceCompact( const Sequence& _refSeq, const Sequence& seq ) : refSeq( _refSeq )
{
	assert( refSeq.size() == seq.size() );
	
	for ( int i = 0; i < seq.size(); i++ ) {
		if ( refSeq[i] != seq[i] ) changes.push_back( make_pair( i, seq[i] ) );
	}
}

void SequenceCompact::reconstructSeq( Sequence& origSeq ) const
{
	origSeq = refSeq;
	for ( int i = 0; i < changes.size(); i++ ) {
		origSeq[ changes[i].first ] = changes[i].second;
	}
}   

ostream& operator<<( ostream& os, const Phenotype& pheno )
{
    os << pheno.exprProfile;
}

void PhenotypeFunc::computePhenotype( const Sequence& seq, Phenotype& pheno ) const
{
// 	if ( contains( seq, consensusSeq ) ) pheno.exprState = 1;
// 	else pheno.exprState = 0;

    // construct the sequence representation as a vector of binding sites
    SiteVec sites;
    SeqAnnotator ann( exprFunc->getMotifs(), energyThrs );	
    ann.annot( seq, sites );
    
    // compute the epxression profile 
    int nConds = env.factorExprProfiles.nCols();
    for ( int j = 0; j < nConds; j++ ) {
        vector< double > concs = env.factorExprProfiles.getCol( j );
        double predicted = exprFunc->predictExpr( sites, seq.size(), concs );
        pheno.exprProfile.push_back( predicted );
    }    
}

// bool PhenotypeFunc::contains( const Sequence& seq, const Sequence& elem )
// {
//     bool result = false;
//     for ( int i = 0; i < seq.size() - elem.size(); i++ ) {
//         Sequence subseq( seq, i, elem.size() );
//         if ( compDistance( subseq, elem ) <= 1 ) {
//             result = true;
//             break;
//         }
//     }

//     return result;
// }

double FitnessFunc::computeFitness( const Phenotype& pheno ) const
{
// 	if ( pheno.exprState == target.exprState ) return ( 1.0 + selectionCoeff );
// 	else return 1.0;

    // compute the RMSE between the phenotype and the target
    double deviation = phenotypeDev( pheno, target );

    // the fitness value is a funciton of RMSE
    return pow( ( 1.0 - deviation / D_max ), selectionPar );
}

double FitnessFunc::phenotypeDev( const Phenotype& pheno1, const Phenotype& pheno2 )
{
    vector< double > profile1 = pheno1.getExprProfile();
    vector< double > profile2 = pheno2.getExprProfile();
    assert( profile1.size() == profile2.size() );

    double error = 0;
    for ( int i = 0; i < profile1.size(); i++ ) {
        error += ( profile1[i] - profile2[i] ) * ( profile1[i] - profile2[i] ); 
    }

    return sqrt( error / profile1.size() );
}

double FitnessFunc::D_max = 1.0;
double FitnessFunc::selectionPar = 1.0;

EvolSimulator::EvolSimulator( const gsl_rng* _rng, double _mutationRate, ExprFunc* _exprFunc, const vector< double >& _energyThrs, const Environment& _env, const Phenotype& _evolTarget ) : rng( _rng ), mutationRate( _mutationRate ), exprFunc( _exprFunc ), energyThrs( _energyThrs ), env( _env ), evolTarget( _evolTarget ), time( 0 )
{
    assert( rng != NULL ); 
    assert( mutationRate >= 0 );

    phenoFunc = new PhenotypeFunc( exprFunc, energyThrs, env );
    fitnessFunc = new FitnessFunc( evolTarget );
}

void EvolSimulator::initialize( int N, const Sequence& initSeq )
{
	refSeq = initSeq;
    time = 1;
	
	// initialize the population and the fitness values
    SequenceCompact seq( initSeq );
    double fitness = computeFitness( seq );
	for ( int i = 0; i < 2 * N; i++ ) {
		population.push_back( seq );	
		fitnesses.push_back( fitness );
	}
}

void EvolSimulator::evolve( int nGenerations )
{
    for ( int t = 0; t < nGenerations; t++ ) {
        time++;

        // set up environment and target phenotype
        
        // sample mutations and apply them on the population 
        double expectedNumMutations = population.size() * refSeq.size() * mutationRate; 
        int nMutations = gsl_ran_poisson( rng, expectedNumMutations );
        for ( int i = 0; i < nMutations; i++ ) {
            int randInd = gsl_rng_uniform_int( rng, population.size() );
            int randPos = gsl_rng_uniform_int( rng, refSeq.size() );
//             cout << "Mutation of sequence " << randInd << " at position " << randPos << endl;
            mutate( population[randInd], randPos );
            fitnesses[randInd] = computeFitness( population[randInd] );
        }

//         cout << "After mutation:" << endl;
//         print();
         
        // selection of individuals for next generation
        vector< int > nextGen;
        sampleNextGeneration( nextGen );
//         cout << "Selected individuals for next generation: " << nextGen << endl;
        
        // update the population: collect the number of offsprings of each individual
        vector< int > nOffsprings( population.size(), 0 );
        for ( int i = 0; i < nextGen.size(); i++ ) {
            nOffsprings[ nextGen[i] ]++;	
        }
//         cout << "Number of offsprings: " << nOffsprings << endl; 
        
        // update the population: list of the dead individuals
        queue< int > deadInds;
        for ( int i = 0; i < population.size(); i++) {
            if ( nOffsprings[i] == 0 ) deadInds.push( i ); 	
        }
        
        // update the pupulation: replace the dead individuals
        for ( int i = 0; i < population.size(); i++ ) {
            if ( nOffsprings[i] <= 1 ) continue;
            for ( int j = 0; j < nOffsprings[i] - 1; j++ ) {
                int emptySpace = deadInds.front();
                population[emptySpace] = population[i];
                fitnesses[emptySpace] = fitnesses[i];
                deadInds.pop();
            }	
        } 

//         cout << "Next generation:" << endl;
        print();
    }
}

void EvolSimulator::print() const
{
    cout << "time = " << time << endl;
    for ( int i = 0; i < population.size(); i++ ) {
        Sequence seq;
        population[i].reconstructSeq( seq );
        cout << seq << "\t" << fitnesses[i] << endl;
    }
}

double EvolSimulator::computeFitness( const SequenceCompact& seq ) const
{
	// the original sequence
	Sequence origSeq;
	seq.reconstructSeq( origSeq );
	
	// the phenotype
	Phenotype pheno;
	phenoFunc->computePhenotype( origSeq, pheno );
	
	// the fitness
	return fitnessFunc->computeFitness( pheno );
}

void EvolSimulator::mutate( SequenceCompact& currSeq, int pos ) const
{
	assert( pos >= 0 && pos < currSeq.refSeq.size() );
	
	// the original sequence
	Sequence seq; 
	currSeq.reconstructSeq( seq );
	
	// random mutation
	int currNt = seq[ pos ];
	vector< double > probs( 4, 1.0 / 3 );
	probs[ currNt ] = 0;
	int mutNt = sampleMul( rng, probs );
	
	// apply the mutation 
	seq[ pos ] = mutNt;
	
	// the compact representation of the mutated sequence
	currSeq = SequenceCompact( refSeq, seq );
}

void EvolSimulator::sampleNextGeneration( vector< int >& nextGen ) const
{
	nextGen.clear();
	
	// sample the intermediate population
	vector< int > intermediatePop;
	for ( int i = 0; i < population.size(); i++ ) {
		int nOffsprings = gsl_ran_poisson( rng, fitnesses[i] );
		for ( int j = 0; j < nOffsprings; j++ ) {
			intermediatePop.push_back( i );	
		}
	}
	
	// sample 2N individuals of next generation
	for ( int i = 0; i < population.size(); i++ ) {
        int idx = gsl_rng_uniform_int( rng, intermediatePop.size() );
		nextGen.push_back( intermediatePop[idx] );
	}
}

double PopulationSummarizer::getBestSeq( Sequence& bestSeq, Phenotype& bestPheno )
{
    // get the index of the best sequence
    double maxFitness = 0;
    int idxBestSeq = 0;
    for ( int i = 0; i < simulator.population.size(); i++ ) {
        if ( simulator.fitnesses[i] > maxFitness ) {
            maxFitness = simulator.fitnesses[i];
            idxBestSeq = i;
        }
    }

    // return the sequence, phenotype and fitness
    simulator.population[idxBestSeq].reconstructSeq( bestSeq );
    simulator.getPhenoFunc()->computePhenotype( bestSeq, bestPheno );
    return maxFitness;
}

void PopulationSummarizer::sampleSeqs( const gsl_rng* rng, int n, vector< Sequence >& seqs ) const
{
	seqs.clear();
	
	for ( int i = 0; i < n; i++ ) {
		// sample an index
		int idx = gsl_rng_uniform_int( rng, simulator.population.size() );
		
		// get the sequence
		Sequence seq;
        simulator.population[idx].reconstructSeq( seq );
		seqs.push_back( seq );
	}
}

void PopulationSummarizer::sampleSeq( const gsl_rng* rng, Sequence& seq ) const
{
    int idx = gsl_rng_uniform_int( rng, simulator.population.size() );
    simulator.population[idx].reconstructSeq( seq );
}
