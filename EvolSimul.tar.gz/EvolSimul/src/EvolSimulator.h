#ifndef EVOL_SIMULATOR_H
#define EVOL_SIMULATOR_H

#include "SeqAnnotator.h"
#include "ExprPredictor.h"

// distance between two sequences (number of substitutions)
int compDistance( const Sequence& seq1, const Sequence& seq2 );

/* SequenceCompact class: the compact representation of a sequence, storing only the differences with a reference sequence */
class SequenceCompact {
	friend class EvolSimulator;
public:
	// constructors
	SequenceCompact( const Sequence& _refSeq ) : refSeq( _refSeq ) {}
	SequenceCompact( const Sequence& _refSeq, const vector< pair< int, int > > _changes ) : refSeq( _refSeq ), changes( _changes ) {}
	SequenceCompact( const Sequence& _refSeq, const Sequence& seq );	// the compact representation of the input "seq"
	void copy( const SequenceCompact& other ) { changes = other.changes; } 
	SequenceCompact( const SequenceCompact& other ) : refSeq( other.refSeq ) { copy( other ); }
	
	// assignment
    SequenceCompact& operator=( const SequenceCompact& other ) { copy( other ); return *this; }
    
    // reconstruct the original sequence
    void reconstructSeq( Sequence& origSeq ) const;
private:
	const Sequence& refSeq;		// reference sequence
	vector< pair< int, int > > changes;		// changes relative to the reference sequence
};

/* Environment class: the trans- conditions that affect the phenotype */
class Environment {
    friend class PhenotypeFunc;
public:
	// constructors
    Environment( const Matrix& _factorExprProfiles ) : factorExprProfiles( _factorExprProfiles ) {}
    void copy( const Environment& other ) {
        factorExprProfiles = other.factorExprProfiles;
    }
    Environment( const Environment& other ) {
        copy( other ); 
    }
	
    // assignment
    Environment& operator=( const Environment& other ) { copy( other ); return *this; }

    // access methods
    const Matrix& getFactorExprProfiles() const {
        return factorExprProfiles;
    }
private:	
	Matrix factorExprProfiles;	// the expression profiles of transcription factors
};

/* Phenotype class: the phenotype of the sequence */
class Phenotype {
	friend class PhenotypeFunc;
    friend class FitnessFunc;
public: 
	// constructors
	Phenotype() : exprProfile() {}
	Phenotype( const vector< double > _exprProfile ) : exprProfile( _exprProfile ) {}
    void copy( const Phenotype& other ) {
        exprProfile = other.exprProfile;
    }
    Phenotype( const Environment& other ) {
        copy( other );
    }

    // assignment
    Phenotype& operator=( const Phenotype& other ) { copy( other ); return *this; }
    
    // access methods
    const vector< double >& getExprProfile() const {
        return exprProfile;
    }
    
    // print
    friend ostream& operator<<( ostream& os, const Phenotype& pheno );
private:	
    vector< double > exprProfile;   // 1D expression profile
};

/* PhenotypeFunc class: the genotype-phenotyp map */
class PhenotypeFunc {
public: 
	// constructors
	PhenotypeFunc( ExprFunc* _exprFunc, const vector< double >& _energyThrs, const Environment& _env ) : exprFunc( _exprFunc ), energyThrs( _energyThrs ), env( _env ) {}

	// compute the phenotype from the sequence and environment
	void computePhenotype( const Sequence& seq, Phenotype& pheno ) const;

    // test if a sequence contains another sequence (as a substring)
//     static bool contains( const Sequence& seq, const Sequence& elem );   
private:
    ExprFunc* exprFunc;      // ExprFunc object to compute the phenotype of a sequence
    const vector< double >& energyThrs;	    // energy thresholds for all motifs  
    const Environment& env;        // environment
};

/* FitnessFunc class: the fitness function that maps phenotype to fitness */
class FitnessFunc {
public:
	// constructors
	FitnessFunc( const Phenotype& _target ) : target( _target ) {}
	
	// compute the fitness of a phenotype: (1- D/D_max)^p
	double computeFitness( const Phenotype& pheno ) const;

    //The deviation between two phenotypes: root mean squared error
    static double phenotypeDev( const Phenotype& pheno1, const Phenotype& pheno2 );

    // the maximum deviation
    static double D_max; 

    // the parameter of selection (p)
    static double selectionPar;
private: 
    Phenotype target;   // target phenotype
};

/* EvolSimulator class: simulate the evolution of a population of sequences */
class EvolSimulator {
    friend class PopulationSummarizer;
public: 
	// constructors
	EvolSimulator( const gsl_rng* _rng, double _mutationRate, ExprFunc* _exprFunc, const vector< double >& _energyThrs, const Environment& _env, const Phenotype& _evolTarget );

    // access methods
    int getTime() const {
        return time;
    }
    const PhenotypeFunc* getPhenoFunc() const {
        return phenoFunc;
    }
    const FitnessFunc* getFitnessFunc() const {
        return fitnessFunc;
    }
    
	// initialize the population with a sequence 
	void initialize( int N, const Sequence& initSeq );
	
	// evolve the population for a certain number of generations
	void evolve( int nGenerations );

    // print the population (for debugging purpose)
    void print() const;
private: 
	const gsl_rng* rng; 	// random number generator

    double mutationRate;		// mutation rate
    ExprFunc* exprFunc;  // the ExprFunc object, containing the relevant parameters
    vector< double > energyThrs;     // the energy thresholds for all motifs
	Environment env;	// the current environment
	Phenotype evolTarget;	// the evolutionary target
//     double selectionCoeff;  // the selection coefficient
	
	int time;	// the current generation time
	Sequence refSeq;	// the reference sequence
	vector< SequenceCompact > population;	// the current population of sequences
	vector< double > fitnesses;		// the fitness of each sequence
	
	PhenotypeFunc* phenoFunc;		// genotype-to-phenotype function
	FitnessFunc* fitnessFunc;		// phenotype-to-fitness function
	
	// compute the fitness of a sequence
//     double computePhenotype( const SequenceCompact& seq ) const;
	double computeFitness( const SequenceCompact& seq ) const;
	
	// mutation of one sequence (random substitution)
	void mutate( SequenceCompact& currSeq, int pos ) const;
	
	// sample next generation of 2N individuals
	void sampleNextGeneration( vector< int >& nextGen ) const; 		
};

/* PopulationSummarizer class: summarize the statistics of a population, e.g. consensus sequence, best phenotype, etc. */
class PopulationSummarizer {
public: 
	// constructors
	PopulationSummarizer( const EvolSimulator& _simulator ) : simulator( _simulator ) {}

    // the sequence with the highest fitness: return the fitness value
    double getBestSeq( Sequence& bestSeq, Phenotype& bestPheno );
    
	// sample a set of sequences from the population
	void sampleSeqs( const gsl_rng* rng, int n, vector< Sequence >& seqs ) const;

    // sample a single sequence from the population
    void sampleSeq( const gsl_rng* rng, Sequence& seq ) const;
private: 
	const EvolSimulator& simulator;		// reference to the evolutionary simulator	
};

#endif

