Simulating Evolution of Regulatory Sequences
Author: Xin He <xinhe2@illinois.edu>
--------------------------------------------------------------------------
INSTALLATION

The program needs GSL (GNU Scientific Library). After installing GSL, change the GSL directory in src/Makefile. Then type: 
cd src
make

The main executable will be generates: 
simul_evol: the main program to simulate the evolution of a regulatory sequence

Type the program name without parameters will print usage information. 
--------------------------------------------------------------------------
PROGRAM USAGE

The program simulates the evolution of CRMs. The fitness of a CRM is defined by the similarity of its expression pattern and the target pattern. At each generation, random mutations occur in the population and the new sequences are selected according to the fitness value. The program takes as input: the starting sequence, the PWMs, the expression profiles and the parameters of relevant TFs, and the evolution target (expression pattern). The output will be the population of sequences at each generation. 

The examples/ directory contain the example files. A simple command of running the program: 
$INSTALL_DIR/src/simul_evol -m factors.wtmx -f factor_expr.tab -i factor_info.txt -s eve_stripe2.fa -e eve_stripe2.tab 

Explanation of parameters: 
-m <motif_file>: required, the PWM (motif) of the relevant TFs. See examples/factors.wtmx. 

-f <factor_expr_file>: required, the expression data of the TFs. Must match the format of expr_file, and the order of TFs in motif_file. See examples/factor_expr.tab. 

-i <factor_info_file>: required, the information of TFs. The second column is the binding parameter and the third the expression parameter (alpha). See examples/factor_info.txt. 

-s <seq_file>: required, the sequence file in FASTA format. The starting sequence of the population. See examples/eve_stripe2.fa. 

-e <expr_file>: required, the target expression of the population. The first line specifies the name of the expression conditions. See examples/eve_stripe2.tab. 

-o <model_option>: the sequence-to-expression model. Options are: Logistic, Direct (DirectInt model), ChrMod_Unlimited (SRR model with N_MA = inf), ChrMod_Limited (SRR model with finite N_MA). 

-c <coop_file>: the list of cooperative interactions. One line per cooperative pair. If not specified, then no cooperative interaction is allowed. See examples/coop_file. 
--------------------------------------------------------------------------
SOURCE CODE

The main classes and functions of the program: 

Tools.*
The utility classes and functions, e.g. Matrix class, mathematical functions, I/O classes. 

class Sequence (SeqAnnotator.h): 
The DNA sequences, represented as a vector of A,C,G,T. The functions that read and write sequences in FASTA format are also included. 

class Motif (SeqAnnotator.h): 
The PWM representation of binding profiles. Defined the methods for computing the LLR score and mismatch energy of any sequence element. Also included read/write functions. 

class Site (SeqAnnotator.h): 
The TF binding sites. The data members are: position, which TF the site is associted with (index), and its mismatch energy and binding affinity (:= exp(-energy)). 

class SeqAnnotator (SeqAnnotator.h): 
Create the site representation of a sequence, i.e. a Sequence object can now be represented as a vector of Site objects. All sites that exceed certain energy thresholds will be extracted. 

class FactorIntFunc (ExprPredictor.h): 
The function that computes the interaction between two occupied TFBSs, according to the TF pairs, the distance and orientation of the sites. 

class ExprPar (ExprPredictor.h): 
The parameters of a sequence-to-expression model, including the binding parameters (K of the strongest site multiplied by TF_max, see the paper), the activation parameters (alpha), the repression parameters (beta), the basal transcription, and the TF-TF interaction matrix. Because some models only have a subset of these parameters (e.g. beta is only used in the SRR model),  methods are defined to: 1) create an ExprPar object by a vector of free parameters (constructor); 2) extract all free parameters from the ExprPar object: getFreePars() function. Exactly how these methods are implemented depend on the current model option (static ModelType modelOption). 

class ExprFunc (ExprPredictor.h): 
The class that predicts expression level of a sequence (represented by a vector of Site objects)according to TF expression levels and the model parameters. The main function is predictExpr(). For thermodynamic models, this main function is implemented through compPartFuncOff() and compPartFuncOn(). These two functions implemented the dynamic programming algorithms in the paper. Also note that all model parameters are supposed to known. 

class ExprPredictor (ExprPredictor.h): 
This class is used for fitting sequence-to-expression model. However, it is not used in this program.

class SequenceCompact (EvolSimulator.h): 
The compact representation of a sequence.Normally, all sequences in a population are very similar, so only need to store the differences with a reference sequence. 

class Environment (EvolSimulator.h): 
The trans- conditions that affect the phenotype. The phenotype (fitness) of a sequence depends both on the sequence and the environment. In our case, the environment is the TF expression profiles. 

class Phenotype (EvolSimulator.h): 
The phenotype of the sequence. In our case, it is the expression profile of a sequence. 

class PhenotypeFunc(EvolSimulator.h): 
The genotype-phenotyp map, i.e. the mapping between sequence to expression profile. 

class FitnessFunc (EvolSimulator.h):
The phenotype to fitness mapping. This is determined by the evolutionary target, which is a data member of this class. 

class EvolSimulator (EvolSimulator.h):
The main method is evolve(). The simulator first use initialize() function to initialize the populatoin, then evolve() to evolve the population for a certain number of generations. 

class PopulationSummarizer (EvolSimulator.h): 
Summarize the statistics of a population, e.g. consensus sequence, best phenotype, etc.

simul_evol.cpp
The main() function. The default values of many parameters are defined here. Also control the output. 

